package com.example.transportz;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class BusAdapter extends RecyclerView.Adapter<BusAdapter.ViewHolder> {
    private List<Bus> busList;

    public BusAdapter(List<Bus> busList) {
        this.busList = busList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bus_timing_card, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Bus bus = busList.get(position);
        holder.bind(bus);
    }

    @Override
    public int getItemCount() {
        return busList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView busIdTextView;
        private TextView totalSeatsTextView;
        private TextView typeTextView;
        private TextView startTimeTextView;
        private TextView gapTextView;
        private TextView arrivalTimeTextView;
        private TextView availableSeatsTextView;
        Bus bus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            busIdTextView = itemView.findViewById(R.id.busId);
            totalSeatsTextView = itemView.findViewById(R.id.totalSeats);
            startTimeTextView = itemView.findViewById(R.id.startTime);
            gapTextView = itemView.findViewById(R.id.gap);
            arrivalTimeTextView = itemView.findViewById(R.id.arrivalTime);
            availableSeatsTextView = itemView.findViewById(R.id.availableSeats);

            itemView.setOnClickListener(v -> {
                AlertDialog.Builder builder = new AlertDialog.Builder(itemView.getContext());
                builder.setMessage("Request for the Bus?")
                        .setPositiveButton("Request", (dialog, which) -> {
                            SharedPreferences sharedPreferences = itemView.getContext().getSharedPreferences("UserDetails", Context.MODE_PRIVATE);
                            int userId = sharedPreferences.getInt("userId", -1); // Assuming 'userId' is stored in SharedPreferences
                            if (userId != -1) {
                                DBHelper databaseHelper = new DBHelper(itemView.getContext());
                                SQLiteDatabase db = databaseHelper.getWritableDatabase();
                                ContentValues values = new ContentValues();
                                values.put("busId", bus.getId());
                                values.put("userId", userId);
                                values.put("status", "Pending");
                                values.put("date", (new Date()).toString());
                                long newRowId = db.insert("travelRequests", null, values);
                                if (newRowId != -1) {
                                    // Row inserted successfully
                                    Toast.makeText(itemView.getContext(), "Request sent!", Toast.LENGTH_SHORT).show();
                                } else {
                                    // Failed to insert row
                                    Toast.makeText(itemView.getContext(), "Failed to send request!", Toast.LENGTH_SHORT).show();
                                }
                                db.close();
                            } else {
                                // 'userId' not found in SharedPreferences
                                Toast.makeText(itemView.getContext(), "User not found!", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            dialog.dismiss();
                        })
                        .show();
            });
        }

        public void bind(Bus bus) {
            this.bus = bus;
            busIdTextView.setText("Bus-" + bus.getId());
            totalSeatsTextView.setText(String.valueOf(bus.getTotalSeats()));
            startTimeTextView.setText(bus.getStartTime());
            try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date start = sdf.parse(bus.getStartTime());
            Date arrival = sdf.parse(bus.getArrivalTIme());
            long diff = arrival.getTime() - start.getTime();
            long diffMinutes = diff / (60 * 1000) % 60;
            long diffHours = diff / (60 * 60 * 1000);
            gapTextView.setText(String.format(Locale.getDefault(), "%d hrs %d mins", diffHours, diffMinutes));
            } catch (
            ParseException e) {
                e.printStackTrace();
            }
            arrivalTimeTextView.setText(bus.getArrivalTIme());
            availableSeatsTextView.setText(String.valueOf(bus.getAvailableSeats()));
        }
    }
}
