package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class StudentLogin extends AppCompatActivity {

    LinearLayout annual, dialy;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        annual = findViewById(R.id.annual);
        dialy = findViewById(R.id.dialy);

        annual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(StudentLogin.this, Login.class);
                i.putExtra("role", "Student");
                i.putExtra("annualOrDialy", "annual");
                startActivity(i);
            }
        });

        dialy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(StudentLogin.this, Login.class);
                i.putExtra("role", "Student");
                i.putExtra("annualOrDialy", "dialy");
                startActivity(i);
            }
        });
    }
}