package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SignUp extends AppCompatActivity {

    Button signupBtn;
    int selectedBusId;
    TextView textViewLogin;

    @Override
    @SuppressLint("Range")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        Spinner destinationSpinner = findViewById(R.id.destinationET);
        textViewLogin = findViewById(R.id.textViewLogin);

        textViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(SignUp.this, "sdftgyhujihugytfrd", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SignUp.this, Login.class);
                startActivity(intent);
            }
        });

        DBHelper dbHelper = new DBHelper(SignUp.this);
        Cursor busCursor = dbHelper.getAllBusDetails();

        List<Integer> busIds = new ArrayList<Integer>();
        List<String> values = new ArrayList<String>();
        busIds.add(-1);
        values.add("Select a destination");
        while (busCursor.moveToNext()) {
            int busId = busCursor.getInt(busCursor.getColumnIndex("busId"));
            String busRoute = busCursor.getString(busCursor.getColumnIndex("route"));

            busIds.add(busId);
            values.add(busRoute);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(SignUp.this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        destinationSpinner.setAdapter(adapter);

        selectedBusId = -1;
        destinationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                selectedBusId = busIds.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }

        });

        signupBtn = findViewById(R.id.signupBtn);
        signupBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String boardingPoint = ((EditText) findViewById(R.id.userIdET)).getText().toString().trim();
                String name = ((EditText) findViewById(R.id.nameET)).getText().toString().trim();
                String password = ((EditText) findViewById(R.id.passwordET)).getText().toString().trim();
                String bloodGroup = ((EditText) findViewById(R.id.bloodGrpET)).getText().toString().trim();
                String phoneNumber = ((EditText) findViewById(R.id.phNoET)).getText().toString().trim();
                String address = ((EditText) findViewById(R.id.addressET)).getText().toString().trim();

                long inserted = dbHelper.insertUser(SignUp.this, "Student", name, selectedBusId, password, bloodGroup, phoneNumber, address, boardingPoint, getIntent().getStringExtra("annualOrDialy"));
                long id = dbHelper.insertWallet(inserted);
                if (inserted != -1 && id != -1) {
                    Intent intent = new Intent(SignUp.this, LoginButtons.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}