package com.example.transportz;

import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.function.IntFunction;

public class Bus {
    private int id;
    private String route;

    private int inchargeId, driverId;
    private int totalSeats, occupiedSeats, availableSeats;

    private String startTime, arrivalTIme;



    public Bus(int id, String route, int inchargeId, int driverId, int totalSeats, int occupiedSeats, int availableSeats, String startTime, String arrivalTime) {
        this.id = id;
        this.route = route;
        this.inchargeId = inchargeId;
        this.driverId = driverId;
        this.totalSeats = totalSeats;
        this.occupiedSeats = occupiedSeats;
        this.availableSeats = availableSeats;
        this.startTime = startTime;
        this.arrivalTIme = arrivalTime;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getArrivalTIme() {
        return arrivalTIme;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public int getOccupiedSeats() {
        return occupiedSeats;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public int getInchargeId() {
        return inchargeId;
    }

    public void setInchargeId(int inchargeId) {
        this.inchargeId = inchargeId;
    }

    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }
}

