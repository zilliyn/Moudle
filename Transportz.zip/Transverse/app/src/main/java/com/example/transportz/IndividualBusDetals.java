package com.example.transportz;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class IndividualBusDetals extends AppCompatActivity {

    private TextView totalSeatsTextView;
    private TextView availableSeatsTextView;
    private TextView occupiedSeatsTextView;
    private TextView driverNameTextView;
    private TextView driverContactTextView;

    @Override
    @SuppressLint("Range")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_bus_detals);

        totalSeatsTextView = findViewById(R.id.totalSeats);
        availableSeatsTextView = findViewById(R.id.available);
        occupiedSeatsTextView = findViewById(R.id.occupied);
        driverNameTextView = findViewById(R.id.driverName);
        driverContactTextView = findViewById(R.id.driverContact);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            int busId = extras.getInt("busId");

            Log.d("budId", String.valueOf(busId));

            DBHelper dbHelper = new DBHelper(this);
            Cursor cursor = dbHelper.getBusDetails(busId);


            if (cursor.moveToFirst()) {
                totalSeatsTextView.setText("Total seats: " + cursor.getInt(cursor.getColumnIndex("totalSeats")));
                availableSeatsTextView.setText("Available seats: " + cursor.getInt(cursor.getColumnIndex("availableSeats")));
                occupiedSeatsTextView.setText("Occupied seats: " + cursor.getInt(cursor.getColumnIndex("occupiedSeats")));

                int driverId = cursor.getInt(cursor.getColumnIndex("driverId"));
                Cursor driverCursor = dbHelper.getDriverDetails(driverId);

                if (driverCursor.moveToFirst()) {
                    String driverName = driverCursor.getString(driverCursor.getColumnIndex("name"));
                    String driverContact = driverCursor.getString(driverCursor.getColumnIndex("phoneNumber"));
                    driverNameTextView.setText("Driver Name: " + driverName);
                    driverContactTextView.setText("Driver Contact: " + driverContact);
                }

                driverCursor.close();
            }

            cursor.close();
            dbHelper.close();
        }
       /* ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(IndividualBusDetals.this, R.color.white)));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);
        actionBar.setDisplayShowTitleEnabled(true);*/
    }
}
