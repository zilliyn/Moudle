package com.example.transportz;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class AddFeedback extends AppCompatActivity {
    private Spinner feedbackTypeSpinner;
    private EditText feedbackDescriptionEditText;
    private Button submitButton;

    private DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_feedback);
/*
        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.white)));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);
        actionBar.setDisplayShowTitleEnabled(false);*/

        dbHelper = new DBHelper(this);

        feedbackTypeSpinner = findViewById(R.id.feedbackTypeSpinner);
        feedbackDescriptionEditText = findViewById(R.id.feedbackDescriptionEditText);
        submitButton = findViewById(R.id.submitButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.feedback_types_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        feedbackTypeSpinner.setAdapter(adapter);



        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addFeedbackToDB();
            }
        });
    }

    private void addFeedbackToDB() {
        String feedbackType = feedbackTypeSpinner.getSelectedItem().toString();
        String description = feedbackDescriptionEditText.getText().toString();

        if (feedbackType.equals("Select type")) {
            Toast.makeText(this, "Please select a feedback type", Toast.LENGTH_SHORT).show();
            return;
        }


        if(description.isEmpty()) {
            Toast.makeText(this, "Please give some description.", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        int userID = sharedPreferences.getInt("userId", -1);

        if (userID == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long id = dbHelper.addFeedback(db, feedbackType, description, userID);
        Toast.makeText(this, "Feedback submitted", Toast.LENGTH_SHORT).show();
    }
}