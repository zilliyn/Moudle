package com.example.transportz;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.TimePickerDialog;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

public class AddBus extends AppCompatActivity {

    EditText busIdEditText, routeEditText, totalSeatsEditText, availableSeatsEditText, occupiedSeatsEditText;
    EditText driverNameEditText, driverContactEditText;
    EditText inchargeIdEditText, inchargeNameEditText, inchargeContactEditText;
    Button startTimeEditText, arrivalTimeEditText;
    TextView startTime, arrivalTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bus);

         startTimeEditText = findViewById(R.id.startTime);
         arrivalTimeEditText = findViewById(R.id.arrivalTime);

        startTime = findViewById(R.id.txtStartTime);
        arrivalTime = findViewById(R.id.txtArrivalTime);

        startTimeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // on below line we are getting the
                // instance of our calendar.
                final Calendar c = Calendar.getInstance();

                // on below line we are getting our hour, minute.
                int hour = c.get(Calendar.HOUR_OF_DAY);
                int minute = c.get(Calendar.MINUTE);

                // on below line we are initializing our Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(AddBus.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                // on below line we are setting selected time
                                // in our text view.
                                startTime.setText(hourOfDay + ":" + minute);
                            }
                        }, hour, minute, false);
                // at last we are calling show to
                // display our time picker dialog.
                timePickerDialog.show();
            }
        });

        arrivalTimeEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // on below line we are getting the
                // instance of our calendar.
                final Calendar c = Calendar.getInstance();

                // on below line we are getting our hour, minute.
                int hour = c.get(Calendar.HOUR_OF_DAY);
                int minute = c.get(Calendar.MINUTE);

                // on below line we are initializing our Time Picker Dialog
                TimePickerDialog timePickerDialog = new TimePickerDialog(AddBus.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay,
                                                  int minute) {
                                // on below line we are setting selected time
                                // in our text view.
                                arrivalTime.setText(hourOfDay + ":" + minute);
                            }
                        }, hour, minute, false);
                // at last we are calling show to
                // display our time picker dialog.
                timePickerDialog.show();
            }
        });


        Button addButton = findViewById(R.id.addButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                busIdEditText = findViewById(R.id.busIdEditText);
                routeEditText = findViewById(R.id.routeEditText);
                totalSeatsEditText = findViewById(R.id.totalSeatsEditText);
                availableSeatsEditText = findViewById(R.id.availableSeatsEditText);
                occupiedSeatsEditText = findViewById(R.id.occupiedSeatsEditText);
                driverNameEditText = findViewById(R.id.driverNameEditText);
                driverContactEditText = findViewById(R.id.driverContactEditText);
                inchargeNameEditText = findViewById(R.id.inchargeNameEditText);
//                inchargeIdEditText = findViewById(R.id.inchargeIdEditText);
                inchargeContactEditText = findViewById(R.id.inchargeContactEditText);
                DBHelper dbHelper = new DBHelper(AddBus.this);
                String busId = busIdEditText.getText().toString();
                String route = routeEditText.getText().toString();



                if (!validateInputs()) {
                    return;
                }

                int totalSeats = Integer.parseInt(totalSeatsEditText.getText().toString());
                int availableSeats = Integer.parseInt(availableSeatsEditText.getText().toString());
                int occupiedSeats = Integer.parseInt(occupiedSeatsEditText.getText().toString());
                String driverName = driverNameEditText.getText().toString();
                String driverContact = driverContactEditText.getText().toString();
                String inchargeName = inchargeNameEditText.getText().toString();
//                String inchargeId = inchargeIdEditText.getText().toString();
                String inchargeContact = inchargeContactEditText.getText().toString();


                if (!dbHelper.isBusIdAvailable(Long.parseLong(busId))) {
                    Toast.makeText(AddBus.this, "Bus Id already in use", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Check if inchargeId is already present
//                if (!dbHelper.isInchargeIdAvailable(Long.parseLong(inchargeId))) {
//                    Toast.makeText(AddBus.this, "Incharge Id already in use", Toast.LENGTH_SHORT).show();
//                    return;
//                }


                long driverId = dbHelper.insertDriver(driverName, driverContact, Long.parseLong(busId));
                long inchargeIdInserted = dbHelper.insertIncharge(inchargeName, inchargeContact, Long.parseLong(busId));

                dbHelper.insertBusDetails(Long.parseLong(busId), route, totalSeats, availableSeats, occupiedSeats, startTime.getText().toString(), arrivalTimeEditText.getText().toString(), driverId, inchargeIdInserted);

                Toast.makeText(AddBus.this, "Bus details added successfully", Toast.LENGTH_SHORT).show();

                clearInputs();
            }
        });
/*
        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(AddBus.this, R.color.white)));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);
        actionBar.setDisplayShowTitleEnabled(false);*/
    }

    private boolean validateInputs() {

        // Check if any field is empty
        if (
                routeEditText.getText().toString().isEmpty() ||
                totalSeatsEditText.getText().toString().isEmpty() ||
                availableSeatsEditText.getText().toString().isEmpty() ||
                occupiedSeatsEditText.getText().toString().isEmpty() ||
                driverNameEditText.getText().toString().isEmpty() ||
                driverContactEditText.getText().toString().isEmpty() ||
                inchargeNameEditText.getText().toString().isEmpty() ||
                inchargeContactEditText.getText().toString().isEmpty()) {
            Toast.makeText(AddBus.this, "All fields are required", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Validate phone numbers
        if (!isValidPhoneNumber(driverContactEditText.getText().toString()) ||
                !isValidPhoneNumber(inchargeContactEditText.getText().toString())) {
            Toast.makeText(AddBus.this, "Invalid phone number", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("\\d{10}");
    }

    private void clearInputs() {
        busIdEditText.setText("");
        routeEditText.setText("");
        totalSeatsEditText.setText("");
        availableSeatsEditText.setText("");
        occupiedSeatsEditText.setText("");
        driverNameEditText.setText("");
        driverContactEditText.setText("");
        inchargeNameEditText.setText("");
//        inchargeIdEditText.setText("");
        inchargeContactEditText.setText("");
        startTime.setText("");
        arrivalTime.setText("");

    }


}