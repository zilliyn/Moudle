package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ShowListOfUsers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_list_of_users);
    }
}