package com.example.transportz;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class DetailsCardAdapter extends RecyclerView.Adapter<DetailsCardAdapter.PersonViewHolder> implements Filterable {
    private List<Object> items;
    private List<Object> filteredList;

    public DetailsCardAdapter(List<Object> items) {
        this.items = items;
        this.filteredList = new ArrayList<>(items);
    }

    @NonNull
    @Override
    public PersonViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.details_card, parent, false);
        return new PersonViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PersonViewHolder holder, int position) {
        Object item = filteredList.get(position);
        Log.d("instance of", String.valueOf(item instanceof Student));
        Log.d("instance of", String.valueOf(item instanceof InchargeAndDriver));

        if (item instanceof Student) {
            Student student = (Student) item;
            holder.bindStudent(student);
        } else if (item instanceof InchargeAndDriver) {
            InchargeAndDriver inchargeDriver = (InchargeAndDriver) item;
            holder.bindInchargeDriver(inchargeDriver);
        } else if (item instanceof FeedbackDetails) {
            FeedbackDetails feedbackDetails = (FeedbackDetails) item;
            holder.bindFeedBack(feedbackDetails);
        }
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    public void filter(String searchText) {
        filteredList.clear();
        if (searchText.isEmpty()) {
            filteredList.addAll(items);
        } else {
            for (Object item : items) {
                if (item instanceof InchargeAndDriver) {
                    InchargeAndDriver inchargeAndDriver = (InchargeAndDriver) item;
                    if (inchargeAndDriver.getName().toLowerCase().contains(searchText.toLowerCase())) {
                        filteredList.add(item);
                    }
                } else if (item instanceof Student) {
                    Student student = (Student) item;
                    if (student.getName().toLowerCase().contains(searchText.toLowerCase())) {
                        filteredList.add(item);
                    }
                } else if (item instanceof FeedbackDetails) {
                    FeedbackDetails feedbackDetails = (FeedbackDetails) item;
                    if (feedbackDetails.getType().toLowerCase().contains(searchText.toLowerCase())) {
                        filteredList.add(item);
                    }
                }
            }
        }
        notifyDataSetChanged();
    }

    static class PersonViewHolder extends RecyclerView.ViewHolder {
        private TextView idTextView;
        private TextView nameTextView;
        private TextView busIdTextView;
        private TextView routeContactTextView;

        public PersonViewHolder(@NonNull View itemView) {
            super(itemView);
            idTextView = itemView.findViewById(R.id.idTVID);
            nameTextView = itemView.findViewById(R.id.idTVName);
            busIdTextView = itemView.findViewById(R.id.idTVBusID);
            routeContactTextView = itemView.findViewById(R.id.routeOrContact);
        }

        public void bindStudent(Student student) {
            idTextView.setText("Student ID : " + student.getId());
            nameTextView.setText("Student Name : " + student.getName());
            busIdTextView.setText("Bus ID : " + student.getBusId());
            routeContactTextView.setText("Route : " + student.getRoute());
        }

        public void bindInchargeDriver(InchargeAndDriver inchargeDriver) {
            if(inchargeDriver.getType().equals("Incharge")) {
                idTextView.setText("Incharge ID : " + inchargeDriver.getId());
                nameTextView.setText("Incharge Name : " + inchargeDriver.getName());
            } else if(inchargeDriver.getType().equals("Driver")) {
                idTextView.setText("Driver ID : " + inchargeDriver.getId());
                nameTextView.setText("Driver Name : " + inchargeDriver.getName());
            } else if(inchargeDriver.getType().equals("faculty")) {
                idTextView.setText("Faculty ID : " + inchargeDriver.getId());
                nameTextView.setText("Faculty Name : " + inchargeDriver.getName());
            }
            busIdTextView.setText("Bus ID : " + inchargeDriver.getBusId());
            routeContactTextView.setText("Contact Number : " + inchargeDriver.getContactNumber());
        }

        public void bindFeedBack(FeedbackDetails feed) {
            routeContactTextView.setVisibility(View.GONE);
            idTextView.setText("User ID : " + feed.getUserID());
            nameTextView.setText("Feedback Type : "+feed.getType());
            busIdTextView.setText("Feedback Description : "+ feed.getDescription());
        }
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                List<Object> filteredList = new ArrayList<>();

                if (constraint == null || constraint.length() == 0) {
                    filteredList.addAll(items);
                } else {
                    String filterPattern = constraint.toString().toLowerCase().trim();
                    for (Object item : items) {
                        if (item instanceof InchargeAndDriver) {
                            InchargeAndDriver inchargeAndDriver = (InchargeAndDriver) item;
                            if (inchargeAndDriver.getName().toLowerCase().contains(filterPattern)
                                    || inchargeAndDriver.getContactNumber().toLowerCase().contains(filterPattern)) {
                                filteredList.add(item);
                            }
                        } else if (item instanceof Student) {
                            Student student = (Student) item;
                            if (student.getName().toLowerCase().contains(filterPattern)
                                    || student.getRoute().toLowerCase().contains(filterPattern)) {
                                filteredList.add(item);
                            }
                        } else if (item instanceof FeedbackDetails) {
                            FeedbackDetails feedbackDetails = (FeedbackDetails) item;
                            if (feedbackDetails.getType().toLowerCase().contains(filterPattern)
                                    || feedbackDetails.getDescription().toLowerCase().contains(filterPattern)) {
                                filteredList.add(item);
                            }
                        }
                    }
                }

                results.values = filteredList;
                results.count = filteredList.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                filteredList.clear();
                filteredList.addAll((List) results.values);
                notifyDataSetChanged();
            }
        };
    }
}

