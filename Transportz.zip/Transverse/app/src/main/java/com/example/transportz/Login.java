package com.example.transportz;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    TextView textViewSignup;
    EditText usernameET, passwordET;
    Button loginBtn;
    DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameET = findViewById(R.id.usernameET);
        passwordET = findViewById(R.id.passwordET);
        loginBtn = findViewById(R.id.loginBtn);
        dbHelper = new DBHelper(this);
        String role = getIntent().getStringExtra("role");

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameET.getText().toString();
                String password = passwordET.getText().toString();


                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Username and password cannot be empty", Toast.LENGTH_LONG).show();
                    return;
                } else {
                    String annualOrDialy = "";
                    if(getIntent().getStringExtra("annualOrDialy") != null) {
                        annualOrDialy = getIntent().getStringExtra("annualOrDialy");
                    }
                    UserDetails userDetails = dbHelper.getUser(username,password, role, annualOrDialy);
                    System.out.println(userDetails);
                    if (userDetails != null) {

                        SharedPreferences sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putInt("userId", userDetails.getUserID());
                        editor.putString("username", userDetails.getName());
                        editor.putString("password",userDetails.getPassword());
                        editor.putString("designation", userDetails.getDesignation() );
                        editor.putInt("destination", userDetails.getDestination());
                        editor.putString("boardingPoint", userDetails.getBoardingPoint());
                        editor.putString("bloodGroup", userDetails.getBloodGroup());
                        editor.putString("phNo", userDetails.getPhoneNumber());
                        editor.putString("address", userDetails.getAddress());


                        Toast.makeText(Login.this, "Login successful", Toast.LENGTH_LONG).show();

                        if (userDetails.getDesignation().toLowerCase().equals("admin")) {
                            Intent i = new Intent(Login.this, AdminHome.class);
                            startActivity(i);
                            finish();
                        } if (userDetails.getDesignation().toLowerCase().equals("incharge")) {
                            Intent i = new Intent(Login.this, AdminHome.class);
                            startActivity(i);
                            finish();
                        } if (userDetails.getDesignation().toLowerCase().equals("student") && getIntent().getStringExtra("annualOrDialy") != null) {
                            if(getIntent().getStringExtra("annualOrDialy").toLowerCase().equals("annual")) {
                                Intent i = new Intent(Login.this, AdminHome.class);
                                i.putExtra("annualOrDialy", "annual");
                                editor.putString("annualOrDialy", "annual");
                                startActivity(i);
                                finish();
                            } else {
                                Intent i = new Intent(Login.this, AdminHome.class);
                                i.putExtra("annualOrDialy", "dialy");
                                editor.putString("annualOrDialy", "dialy");
                                startActivity(i);
                                finish();
                            }
                        }

                        editor.apply();
                    } else {
                        Toast.makeText(getApplicationContext(), "No " + getIntent().getStringExtra("role") + " with given username and password exists!", Toast.LENGTH_LONG).show();
                    }


                }
            }
        });

        /*ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.white)));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);
        actionBar.setDisplayShowTitleEnabled(false);*/

        textViewSignup = findViewById(R.id.textViewSignup);
        textViewSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Login.this, SignUp.class);
                startActivity(i);
            }
        });
//        SpannableString spannableString = new SpannableString("or Sign Up ?");
//        ClickableSpan clickableSpan = new ClickableSpan() {
//            @Override
//            public void onClick(View widget) {
//                Intent intent = new Intent(Login.this, SignUp.class);
//                intent.putExtra("annualOrDialy", getIntent().getStringExtra("annualOrDialy"));
//                startActivity(intent);
//            }
//
//            @Override
//            public void updateDrawState(TextPaint ds) {
//                super.updateDrawState(ds);
//                ds.setUnderlineText(false);
//            }
//        };
//        spannableString.setSpan(clickableSpan, 0, spannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
//        textViewSignup.setText(spannableString);
//        textViewSignup.setMovementMethod(LinkMovementMethod.getInstance());
//        textViewSignup.setHighlightColor(Color.TRANSPARENT);

//        !role.equalsIgnoreCase("admin" ) &&
        if(!role.equalsIgnoreCase("student")) {
            textViewSignup.setVisibility(View.VISIBLE);  //TODO I have change fromm gone to visible, I need to check the flow and need to change it
        }

        if(role.equalsIgnoreCase("incharge" ) || role.equalsIgnoreCase("admin") ){
            textViewSignup.setVisibility(View.GONE);  //TODO I have change fromm gone to visible, I need to check the flow and need to change it
        }

    }
}