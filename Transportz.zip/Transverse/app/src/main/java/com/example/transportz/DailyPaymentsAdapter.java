package com.example.transportz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DailyPaymentsAdapter extends RecyclerView.Adapter<DailyPaymentsAdapter.PaymentViewHolder> {
    private List<PaymentHistory> paymentHistoryList;

    public DailyPaymentsAdapter(List<PaymentHistory> paymentHistoryList) {
        this.paymentHistoryList = paymentHistoryList;
    }

    @NonNull
    @Override
    public PaymentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.daily_payment_card, parent, false);
        return new PaymentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentViewHolder holder, int position) {
        PaymentHistory paymentHistory = paymentHistoryList.get(position);
        holder.referenceID.setText("Reference ID : " + paymentHistory.getReferenceId());
        holder.busId.setText("Bus Id : " + paymentHistory.getBusId());
        holder.paidDate.setText("Paid on : " + paymentHistory.getPaymentDateTime());
        holder.amount.setText("Total : " + paymentHistory.getAmount());
    }

    @Override
    public int getItemCount() {
        return paymentHistoryList.size();
    }

    public static class PaymentViewHolder extends RecyclerView.ViewHolder {
        TextView referenceID, busId, paidDate, amount;

        public PaymentViewHolder(@NonNull View itemView) {
            super(itemView);
            referenceID = itemView.findViewById(R.id.referenceID);
            busId = itemView.findViewById(R.id.busId);
            paidDate = itemView.findViewById(R.id.paidDate);
            amount = itemView.findViewById(R.id.amount);
        }
    }
}

