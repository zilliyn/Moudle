package com.example.transportz;

public class PaymentHistory {
    private int id;
    private int busId;
    private String paymentDateTime;
    private String referenceId;
    private String validUpto;
    private int userId;
    private int amount;
    private String status;

    public PaymentHistory(int id, int busId, String paymentDateTime, String referenceId, String validUpto, int userId, int amount, String status) {
        this.id = id;
        this.busId = busId;
        this.paymentDateTime = paymentDateTime;
        this.referenceId = referenceId;
        this.validUpto = validUpto;
        this.userId = userId;
        this.amount = amount;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBusId() {
        return busId;
    }

    public void setBusId(int busId) {
        this.busId = busId;
    }

    public String getPaymentDateTime() {
        return paymentDateTime;
    }

    public void setPaymentDateTime(String paymentDateTime) {
        this.paymentDateTime = paymentDateTime;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getValidUpto() {
        return validUpto;
    }

    public void setValidUpto(String validUpto) {
        this.validUpto = validUpto;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
