package com.example.transportz;

public class TravelRequests {

    int id, busId, userId;
    String status;
    String date;

    public TravelRequests(int id, int busId, int userId, String status, String date) {
        this.busId = busId;
        this.userId = userId;
        this.status = status;
        this.date = date;
        this.id = id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setBusId(int busId) {
        this.busId = busId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public int getBusId() {
        return busId;
    }

    public int getUserId() {
        return userId;
    }

    public String getStatus() {
        return status;
    }

    public String getDate() {
        return date;
    }
}
