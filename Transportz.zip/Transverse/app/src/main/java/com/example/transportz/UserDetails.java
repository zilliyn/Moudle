package com.example.transportz;

public class UserDetails {
    private int userID;
    private String name;
    private int destination_bus_id;
    private String boardingPoint;
    private String bloodGroup;
    private String phoneNumber;
    private String address;
    private String designation;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    private String password;
    private String annualOrDialy;

    public UserDetails(int userID, String name, String password, int destination, String bloodGroup, String phoneNumber, String address, String designation, String boardingPoint, String annualOrDialy) {
        this.userID = userID;
        this.name = name;
        this.password = password;
        this.destination_bus_id = destination;
        this.bloodGroup = bloodGroup;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.designation = designation;
        this.boardingPoint = boardingPoint;
        this.annualOrDialy = annualOrDialy;
    }

    public String getAnnualOrDialy() {
        return annualOrDialy;
    }

    public void setAnnualOrDialy(String annualOrDialy) {
        this.annualOrDialy = annualOrDialy;
    }

    public String getBoardingPoint() {
        return boardingPoint;
    }

    public int getUserID() {
        return userID;
    }

    public String getName() {
        return name;
    }

    public int getDestination() {
        return destination_bus_id;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public String getDesignation() {
        return designation;
    }
}

