package com.example.transportz;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NotificationCardAdapter extends RecyclerView.Adapter<NotificationCardAdapter.NotificationCardViewHolder> {
    private List<TravelRequests> notificationCardList;
    String userDesignation;
    private Context context;

    DBHelper dbHelper;

    public NotificationCardAdapter(Context c, List<TravelRequests> notificationCardList, String userDesignation) {
        this.notificationCardList = notificationCardList;
        this.userDesignation = userDesignation;
        this.context = c;
    }

    @NonNull
    @Override
    public NotificationCardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_card, parent, false);
        return new NotificationCardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationCardViewHolder holder, int position) {
        TravelRequests notificationCardModel = notificationCardList.get(position);
        holder.idTVStatus.setText(notificationCardModel.getStatus());
        holder.idTVDate.setText(notificationCardModel.getDate());


        dbHelper = new DBHelper(context);
        int busId = notificationCardModel.getBusId();
        String destination = getRouteForBus(busId);

        if(notificationCardModel.getStatus().toLowerCase().equals("accepted") || notificationCardModel.getStatus().toLowerCase().equals("paid")) {
            int color = ContextCompat.getColor(holder.idTVStatus.getContext(), R.color.green_circle);
            holder.idTVStatus.setTextColor(color);
        } else if(notificationCardModel.getStatus().toLowerCase().equals("rejected")) {
            int color = ContextCompat.getColor(holder.idTVStatus.getContext(), R.color.red_circle);
            holder.idTVStatus.setTextColor(color);
        }

        if (userDesignation.equals("Student")) {
            // Hide buttons and destination
            holder.idTVStudentName.setText("Bus-"+notificationCardModel.getBusId());
            holder.destinationTextView.setVisibility(View.GONE);
            holder.button1.setVisibility(View.GONE);
            holder.button2.setVisibility(View.GONE);

            String annualOrDialy =context.getSharedPreferences("UserDetails", context.MODE_PRIVATE).getString("annualOrDialy", "");

            if (notificationCardModel.getStatus().equalsIgnoreCase("Accepted")) {
                holder.button1.setVisibility(View.VISIBLE);
                holder.button1.setText("Pay");

                holder.button1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dbHelper.updateTravelRequestStatus(notificationCardModel.getId(), "Paid");
                        notifyDataSetChanged();
                        Intent intent = new Intent(context, PaymentPage.class);
                        intent.putExtra("busId", notificationCardModel.getBusId());
                        if( annualOrDialy != null && annualOrDialy.equalsIgnoreCase("annual") ) {
                            intent.putExtra("amount", 40000);
                        } else {
                            intent.putExtra("amount", 30);
                        }
                        Log.d("BUSID TO PAyment", notificationCardModel.getBusId()+"");
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);
                    }
                });
            }
        } else {
            holder.idTVStudentName.setText("Student-"+notificationCardModel.getUserId());
            // Show destination
            holder.destinationTextView.setVisibility(View.VISIBLE);
            holder.destinationTextView.setText(destination);

            // Check status and set visibility and text accordingly
            if (notificationCardModel.getStatus().equalsIgnoreCase("Pending")) {
                // Hide date and status, show buttons
                holder.idTVStatus.setVisibility(View.GONE);
                holder.idTVDate.setVisibility(View.GONE);
                holder.button1.setVisibility(View.VISIBLE);
                holder.button2.setVisibility(View.VISIBLE);

                holder.button1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Update status to "Accepted"
                        notificationCardModel.setStatus("Accepted");

                        dbHelper.updateTravelRequestStatus(notificationCardModel.getId(), "Accepted");
                        notifyDataSetChanged();
                    }
                });

                holder.button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Update status to "Accepted"
                        notificationCardModel.setStatus("Rejected");

                        dbHelper.updateTravelRequestStatus(notificationCardModel.getId(), "Rejected");
                        notifyDataSetChanged();
                    }
                });

            } else {
                // Show status, hide buttons
                holder.idTVStatus.setVisibility(View.VISIBLE);
                holder.idTVStatus.setText(notificationCardModel.getStatus());
                holder.idTVDate.setVisibility(View.VISIBLE);
                holder.idTVDate.setText(notificationCardModel.getDate());
                holder.button1.setVisibility(View.GONE);
                holder.button2.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public int getItemCount() {
        return notificationCardList.size();
    }

    public static class NotificationCardViewHolder extends RecyclerView.ViewHolder {
        TextView idTVStudentName, idTVStatus, idTVDate, destinationTextView;
        Button button1, button2;

        public NotificationCardViewHolder(@NonNull View itemView) {
            super(itemView);
            idTVStudentName = itemView.findViewById(R.id.idTVStudentName);
            idTVStatus = itemView.findViewById(R.id.idTVStatus);
            idTVDate = itemView.findViewById(R.id.idTVDate);
            destinationTextView = itemView.findViewById(R.id.destinationTextView);
            button1 = itemView.findViewById(R.id.button1);
            button2 = itemView.findViewById(R.id.button2);
        }
    }

    private String getRouteForBus(int busId) {
        DBHelper dbHelper = new DBHelper(context);

        Cursor c = dbHelper.getBusDetails(busId);
        if (c != null && c.moveToFirst()) {
            @SuppressLint("Range") String route = c.getString(c.getColumnIndex("route"));
            c.close();
            return route;
        }

        return "Unknown Route"; // Return a default value if the route is not found
    }

}

