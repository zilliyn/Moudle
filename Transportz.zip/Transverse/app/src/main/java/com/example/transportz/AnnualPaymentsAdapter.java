package com.example.transportz;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AnnualPaymentsAdapter extends RecyclerView.Adapter<AnnualPaymentsAdapter.PaymentViewHolder> {
    private List<PaymentHistory> paymentHistoryList;
    Context context;

    public AnnualPaymentsAdapter(List<PaymentHistory> paymentHistoryList, Context context) {
        this.paymentHistoryList = paymentHistoryList;
        this.context = context;
    }

    @NonNull
    @Override
    public PaymentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.annual_payment_card, parent, false);
        return new PaymentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentViewHolder holder, int position) {
        PaymentHistory paymentHistory = paymentHistoryList.get(position);

        if(paymentHistory.getStatus().equalsIgnoreCase("active")) {
            holder.heading.setText("History");
            holder.c1.setText("Amount");
            holder.c2.setText("Mode");
            holder.c3.setText("Reference No");

            holder.r1.setText(paymentHistory.getAmount()+"");
            holder.r2.setText("Online");
            holder.r3.setText(paymentHistory.getReferenceId());

            holder.payBtn.setVisibility(View.GONE);
            holder.totalAmount.setVisibility(View.GONE);
        } else {
            holder.heading.setText("Payment");
            holder.c1.setText("Type");
            holder.heading.setBackgroundColor( ContextCompat.getColor(context, R.color.red_circle));
            holder.c2.setText("Amount");
            holder.c3.setText("Status");

            holder.r1.setText("Bus Fee");
            holder.r2.setText("40000");
            holder.busId.setText("Bus-"+paymentHistory.getBusId());
            holder.r3.setVisibility(View.GONE);

            holder.payBtn.setVisibility(View.VISIBLE);

            holder.totalAmount.setText("Total Amount : 40000");
            holder.totalAmount.setBackgroundColor( ContextCompat.getColor(context, R.color.red_circle));

            holder.payBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i = new Intent(context, PaymentPage.class);
                    i.putExtra("busId", paymentHistory.getBusId());
                    i.putExtra("amount", 40000);
                    context.startActivity(i);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return paymentHistoryList.size();
    }

    public static class PaymentViewHolder extends RecyclerView.ViewHolder {
        TextView r1, r2, r3, c1, c2, c3, heading, totalAmount, busId;
        Button payBtn;

        public PaymentViewHolder(@NonNull View itemView) {
            super(itemView);
            r1 = itemView.findViewById(R.id.row1);
            r2 = itemView.findViewById(R.id.row2);
            r3 = itemView.findViewById(R.id.row3);

            c1 = itemView.findViewById(R.id.col1);
            c2 = itemView.findViewById(R.id.col2);
            c3 = itemView.findViewById(R.id.col3);

            busId = itemView.findViewById(R.id.busId);

            heading = itemView.findViewById(R.id.heading);
            totalAmount = itemView.findViewById(R.id.totalAmount);

            payBtn = itemView.findViewById(R.id.payBtn);


        }
    }
}
