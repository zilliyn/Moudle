package com.example.transportz;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class DetailsPage extends AppCompatActivity implements SearchView.OnQueryTextListener{
    private RecyclerView rv;
    private DetailsCardAdapter adapter;
    private List<Object> dataList = new ArrayList<>();
    @Override
    @SuppressLint("Range")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_page);

        DBHelper dbHelper = new DBHelper(this);

        SharedPreferences userDetails = getSharedPreferences("UserDetails", MODE_PRIVATE);
        int busIdOfLoggedInUser = userDetails.getInt("destination", -1);
        String designation = userDetails.getString("designation", "");
        rv = findViewById(R.id.detailCards);
        if(getIntent().getStringExtra("cardName").equals("Incharge")) {
            Cursor inchargeCursor = dbHelper.getAllIncharges();
            while (inchargeCursor.moveToNext()) {
                int inchargeId = inchargeCursor.getInt(inchargeCursor.getColumnIndex("userID"));
                String name = inchargeCursor.getString(inchargeCursor.getColumnIndex("name"));
                String contact = inchargeCursor.getString(inchargeCursor.getColumnIndex("phoneNumber"));
                int busId = inchargeCursor.getInt(inchargeCursor.getColumnIndex("destination_bus_id"));
                dataList.add(new InchargeAndDriver("Incharge", inchargeId, name, busId, contact));
            }
            inchargeCursor.close();
        } else if(getIntent().getStringExtra("cardName").equals("Driver")) {
            Cursor driverCursor = dbHelper.getAllDrivers();
            if(designation.equalsIgnoreCase("admin")) {
               while (driverCursor.moveToNext()) {
                   int driverId = driverCursor.getInt(driverCursor.getColumnIndex("userID"));
                   String name = driverCursor.getString(driverCursor.getColumnIndex("name"));
                   String contact = driverCursor.getString(driverCursor.getColumnIndex("phoneNumber"));
                   int busId = driverCursor.getInt(driverCursor.getColumnIndex("destination_bus_id"));
                   dataList.add(new InchargeAndDriver("Driver", driverId, name, busId, contact));
               }
           } else {
                while (driverCursor.moveToNext()) {
                    int driverId = driverCursor.getInt(driverCursor.getColumnIndex("userID"));
                    String name = driverCursor.getString(driverCursor.getColumnIndex("name"));
                    String contact = driverCursor.getString(driverCursor.getColumnIndex("phoneNumber"));
                    int busId = driverCursor.getInt(driverCursor.getColumnIndex("destination_bus_id"));
                    if(busId == busIdOfLoggedInUser) {
                        dataList.add(new InchargeAndDriver("Driver", driverId, name, busId, contact));
                    }
                }
           }
            driverCursor.close();
        } else if(getIntent().getStringExtra("cardName").equals("Student")) {
            if(designation.equalsIgnoreCase("admin")) {
                Cursor x = dbHelper.getAllStudents();
                while (x.moveToNext()) {
                    int studentId = x.getInt(x.getColumnIndex("userID"));
                    String name = x.getString(x.getColumnIndex("name"));
                    int busId = x.getInt(x.getColumnIndex("destination_bus_id"));

                    Cursor routeCursor = dbHelper.getBusDetails(busId);
                    String route = "";
                    while (routeCursor.moveToNext()) {
                        route = routeCursor.getString(routeCursor.getColumnIndexOrThrow("route"));
                    }
                    dataList.add(new Student(studentId, name, busId, route));
                }
                x.close();
            } else {
                Cursor studentCursor = dbHelper.getAllStudents(busIdOfLoggedInUser);
                while (studentCursor.moveToNext()) {
                    int studentId = studentCursor.getInt(studentCursor.getColumnIndex("userID"));
                    String name = studentCursor.getString(studentCursor.getColumnIndex("name"));
                    int busId = studentCursor.getInt(studentCursor.getColumnIndex("destination_bus_id"));

                    Cursor routeCursor = dbHelper.getBusDetails(busIdOfLoggedInUser);
                    String route = "";
                    while (routeCursor.moveToNext()) {
                        route = routeCursor.getString(routeCursor.getColumnIndexOrThrow("route"));
                    }
                    dataList.add(new Student(studentId, name, busId, route));
                }
                studentCursor.close();
            }
        } else if (getIntent().getStringExtra("cardName").equals("Feedback")) {
            Cursor feedbackCursor = dbHelper.getAllFeedbackDetails();
            while (feedbackCursor.moveToNext()) {
                int feedbackId = feedbackCursor.getInt(feedbackCursor.getColumnIndex("id"));
                String type = feedbackCursor.getString(feedbackCursor.getColumnIndex("type"));
                String description = feedbackCursor.getString(feedbackCursor.getColumnIndex("description"));
                int userID = feedbackCursor.getInt(feedbackCursor.getColumnIndex("userID"));
                dataList.add(new FeedbackDetails(feedbackId, type, description, userID));
            }
            feedbackCursor.close();
        } else if (getIntent().getStringExtra("cardName").equals("faculty")) {
            Cursor facultyCursor = dbHelper.getAllFaculty(busIdOfLoggedInUser);
            while (facultyCursor.moveToNext()) {
                int driverId = facultyCursor.getInt(facultyCursor.getColumnIndex("userID"));
                String name = facultyCursor.getString(facultyCursor.getColumnIndex("name"));
                String contact = facultyCursor.getString(facultyCursor.getColumnIndex("phoneNumber"));
                int busId = facultyCursor.getInt(facultyCursor.getColumnIndex("destination_bus_id"));
                dataList.add(new InchargeAndDriver("faculty", driverId, name, busId, contact));
            }
            facultyCursor.close();
        }
        adapter = new DetailsCardAdapter(dataList);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(this));

        SearchView searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(this);
/*

        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.white)));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);
        actionBar.setDisplayShowTitleEnabled(false);
*/

    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        adapter.getFilter().filter(newText);
        return true;
    }
}