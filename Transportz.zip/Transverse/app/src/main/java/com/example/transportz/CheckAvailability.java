package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class CheckAvailability extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_availability);

        DatePicker datePicker = findViewById(R.id.date);
        datePicker.init(datePicker.getYear(), datePicker.getMonth(), datePicker.getDayOfMonth(),
                (view, year, monthOfYear, dayOfMonth) -> {
                    String selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                });
        Button searchBtn = findViewById(R.id.searchBtn);
        searchBtn.setOnClickListener(view -> {
            String destination = ((EditText) findViewById(R.id.destination)).getText().toString();
            int dayOfMonth = datePicker.getDayOfMonth();
            int month = datePicker.getMonth() + 1;
            int year = datePicker.getYear();

            Calendar calendar = Calendar.getInstance();
            calendar.set(year, month - 1, dayOfMonth);
            SimpleDateFormat sdf = new SimpleDateFormat("E dd MMM yyyy", Locale.getDefault());
            String date = sdf.format(calendar.getTime());

            Intent intent = new Intent(CheckAvailability.this, ShowAvailableBuses.class);
            intent.putExtra("destination", destination);
            intent.putExtra("date", date);
            startActivity(intent);
        });
    }
}