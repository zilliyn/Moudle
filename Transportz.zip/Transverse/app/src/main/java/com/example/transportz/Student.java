package com.example.transportz;

public class Student {
    private int id;
    private String name;
    private int busId;
    private String route;

    public Student(int id, String name, int busId, String route) {
        this.id = id;
        this.name = name;
        this.busId = busId;
        this.route = route;
    }

    // Getter methods
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getBusId() {
        return busId;
    }

    public String getRoute() {
        return route;
    }
}