package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TravelNotificationList extends AppCompatActivity {
    private RecyclerView recyclerView;
    private NotificationCardAdapter adapter;
    private List<TravelRequests> travelRequestsList;
    private SharedPreferences sharedPreferences;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_travel_notification_list);

        recyclerView = findViewById(R.id.notificationsCards);
        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        dbHelper = new DBHelper(this);
        travelRequestsList = new ArrayList<>();

        int userId = sharedPreferences.getInt("userId", -1);
        int busId = sharedPreferences.getInt("destination", -1);
        if (userId != -1) {
            try {
                String userDesignation = sharedPreferences.getString("designation", "");
                if ("Incharge".equals(userDesignation)) {
                        travelRequestsList = getAllTravelRequestsByBusId(busId);
                } else {
                    travelRequestsList = getAllTravelRequestsByUserId(userId);
                }
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            adapter = new NotificationCardAdapter(getApplicationContext(), travelRequestsList, sharedPreferences.getString("designation", "Student"));
            recyclerView.setAdapter(adapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        }
    }
    @SuppressLint("Range")
    private List<TravelRequests> getAllTravelRequestsByUserId(int userId) throws ParseException {
        List<TravelRequests> travelRequests = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"id", "busId", "userId", "status", "date"};
        String selection = "userId = ?";
        String[] selectionArgs = {String.valueOf(userId)};
        Cursor cursor = db.query("travelRequests", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                int busId = cursor.getInt(cursor.getColumnIndex("busId"));
                int userId1 = cursor.getInt(cursor.getColumnIndex("userId"));
                String status = cursor.getString(cursor.getColumnIndex("status"));
                String date = cursor.getString(cursor.getColumnIndex("date"));
                SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yy", Locale.US);
                Date d = inputFormat.parse(date);
                String outputDate = outputFormat.format(d);
                travelRequests.add(new TravelRequests(id, busId, userId1, status, outputDate.toString()));
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return travelRequests;
    }
    @SuppressLint("Range")
    private List<TravelRequests> getAllTravelRequestsByBusId(int userId) throws ParseException {
        List<TravelRequests> travelRequests = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"busId"};
        String selection = "busId = ?";
        String[] selectionArgs = {String.valueOf(userId)};
        Cursor cursor = db.query("BusDetails", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            int busId = cursor.getInt(cursor.getColumnIndexOrThrow("busId"));
            Log.d("busId", busId+"");

            cursor.close();
            String[] travelRequestColumns = {"id", "busId", "userId", "status", "date"};
            String travelRequestSelection = "busId = ?";
            String[] travelRequestSelectionArgs = {String.valueOf(busId)};
            Cursor travelRequestCursor = db.query("travelRequests", travelRequestColumns, travelRequestSelection, travelRequestSelectionArgs, null, null, null);
            if (travelRequestCursor != null && travelRequestCursor.moveToFirst()) {
                do {
                    int id = travelRequestCursor.getInt(travelRequestCursor.getColumnIndexOrThrow("id"));
                    int userId1 = travelRequestCursor.getInt(travelRequestCursor.getColumnIndex("userId"));
                    String status = travelRequestCursor.getString(travelRequestCursor.getColumnIndex("status"));
                    String date = travelRequestCursor.getString(travelRequestCursor.getColumnIndex("date"));
                    SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                    SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yy", Locale.US);
                    Date d = inputFormat.parse(date);
                    String outputDate = outputFormat.format(d);
                    travelRequests.add(new TravelRequests(id, busId, userId1, status, outputDate.toString()));
                } while (travelRequestCursor.moveToNext());
                travelRequestCursor.close();
            }
        }
        db.close();
        return travelRequests;
    }


}
