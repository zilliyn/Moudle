package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class PaymentPage extends AppCompatActivity {

    private DBHelper dbHelper;
    private SharedPreferences sharedPreferences;
    private int busId;
    private int amount = 30;
    private TextView amountTV;
    private TextView startTimeTextView, arrivalTimeTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_page);

        dbHelper = new DBHelper(this);
        sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);

        startTimeTextView = findViewById(R.id.startTime);
        arrivalTimeTextView = findViewById(R.id.arrivalTime);
        amountTV = findViewById(R.id.amountTV);

        Bundle extras = getIntent().getExtras();
        amount = 30;
        if (extras != null) {
            busId = extras.getInt("busId");
            amount = extras.getInt("amount");
            loadBusDetails(busId);
        }

        amountTV.setText(amount+"");

        ImageView upiBtns = findViewById(R.id.upiBtns);
        ImageView allBtns = findViewById(R.id.allBtns);

        upiBtns.setOnClickListener(v -> makePayment("UPI"));
        allBtns.setOnClickListener(v -> makePayment("All"));

    }
    @SuppressLint("Range")
    private void loadBusDetails(int busId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"startTime", "arrivalTime"};
        String selection = "busId = ?";
        String[] selectionArgs = {String.valueOf(busId)};
        Cursor cursor = db.query("BusDetails", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            String startTime = cursor.getString(cursor.getColumnIndex("startTime"));
            String arrivalTime = cursor.getString(cursor.getColumnIndex("arrivalTime"));
            startTimeTextView.setText(startTime);
            arrivalTimeTextView.setText(arrivalTime);
            cursor.close();
        }
        db.close();
    }

    private void makePayment(String paymentMethod) {
        int userId = sharedPreferences.getInt("userId", -1);
        String role = sharedPreferences.getString("designation", "");
        String annualOrDialy = sharedPreferences.getString("annualOrDialy", "");
        if (userId == -1) {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String currentDateandTime = sdf.format(new Date());
        String referenceId = generateReferenceId();

        Calendar calendar = Calendar.getInstance();
        if (annualOrDialy.equalsIgnoreCase("dialy")) {
            calendar.add(Calendar.HOUR_OF_DAY, 24);
        } else if (annualOrDialy.equalsIgnoreCase("annual")) {
            calendar.add(Calendar.YEAR, 1);
        }
        String validUptoDateTime = sdf.format(calendar.getTime());

        ContentValues values = new ContentValues();
        values.put("paymentDateTime", currentDateandTime);
        values.put("referenceId", referenceId);
        values.put("valid_upto", validUptoDateTime);
        values.put("userId", userId);
        values.put("amount", amount);
        values.put("status", "Active");
        values.put("busId", busId);

        long newRowId = db.insert("paymentsHistory", null, values);
        db.close();

        if (newRowId != -1) {
            Intent i = new Intent(this, SuccessPage.class);
            startActivity(i);
        } else {
            Toast.makeText(this, "Payment failed", Toast.LENGTH_SHORT).show();
        }
    }

    private String generateReferenceId() {
        Random random = new Random();
        int referenceId = random.nextInt(90000000) + 10000000; // Generate 8-digit random number
        return "TZ-" + referenceId;
    }
}
