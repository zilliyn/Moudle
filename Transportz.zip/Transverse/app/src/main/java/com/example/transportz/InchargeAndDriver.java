package com.example.transportz;

public class InchargeAndDriver {
    private String type;
    private int id;

    public String getType() {
        return type;
    }

    private String name;
    private int busId;
    private String contactNumber;

    public InchargeAndDriver(String type, int id, String name, int busId, String contactNumber) {
        this.type = type;
        this.id = id;
        this.name = name;
        this.busId = busId;
        this.contactNumber = contactNumber;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getBusId() {
        return busId;
    }

    public String getContactNumber() {
        return contactNumber;
    }
}
