package com.example.transportz;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class LoginButtons extends AppCompatActivity {

    LinearLayout adminBtn, inchargebtn, passengerBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_buttons);

//        ActionBar actionBar = getSupportActionBar();
//        actionBar.setElevation(0);
//        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.white)));
//        actionBar.setDisplayHomeAsUpEnabled(true);
//        actionBar.setHomeAsUpIndicator(R.drawable.back);
//        actionBar.setDisplayShowTitleEnabled(false);

        adminBtn = findViewById(R.id.adminBtn);
        inchargebtn = findViewById(R.id.inchargeBtn);
        passengerBtn = findViewById(R.id.passengerBtn);

        adminBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Login.class);
                i.putExtra("role", "Admin");
                startActivity(i);
            }
        });

        inchargebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), Login.class);
                i.putExtra("role", "Incharge");
                startActivity(i);
            }
        });

        passengerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), StudentLogin.class);
                startActivity(i);
            }
        });
    }
}