package com.example.transportz;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Transportz";

    private static final String USERS_TABLE = "users";

    private static final String COLUMN_USER_ID = "userID";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_DESTINATION_BUS_ID = "destination_bus_id";
    private static final String COLUMN_BOARDING_POINT = "boarding_point";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_BLOOD_GROUP = "bloodGroup";
    private static final String COLUMN_PHONE_NUMBER = "phoneNumber";
    private static final String COLUMN_ADDRESS = "address";
    private static final String COLUMN_DESIGNATION = "designation";
    private static final String COLUMN_ANNUAL_OR_DIALY = "annualOrDialy";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create Table
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + USERS_TABLE + " (" +
                COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_NAME + " TEXT, " +
                COLUMN_DESTINATION_BUS_ID + " INTEGER, " +
                COLUMN_BOARDING_POINT + " TEXT, " +
                COLUMN_PASSWORD + " TEXT, " +
                COLUMN_BLOOD_GROUP + " TEXT, " +
                COLUMN_PHONE_NUMBER + " TEXT, " +
                COLUMN_ADDRESS + " TEXT, " +
                COLUMN_DESIGNATION + " TEXT, " +
                COLUMN_ANNUAL_OR_DIALY + " TEXT, " +
                "FOREIGN KEY(" + COLUMN_DESTINATION_BUS_ID + ") REFERENCES " +
                "BusDetails" + "(" + "busId" + "))";


        db.execSQL(query);

        db.execSQL("CREATE TABLE travelRequests (\n" +
                "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "    busId INTEGER REFERENCES BusDetails(id),\n" +
                "    userId INTEGER REFERENCES users(id),\n" +
                "    date TEXT,\n" +
                "    status TEXT CHECK(status IN ('Pending', 'Accepted', 'Rejected', 'Paid'))\n" +
                ");\n");
        db.execSQL("CREATE TABLE BusDetails (busId INTEGER PRIMARY KEY, route TEXT, totalSeats INTEGER, availableSeats INTEGER, occupiedSeats INTEGER, driverId INTEGER, inchargeId INTEGER, startTime TEXT, arrivalTime TEXT, FOREIGN KEY(driverId) REFERENCES users(userID), FOREIGN KEY(inchargeId) REFERENCES users(userID))");
        db.execSQL("CREATE TABLE paymentsHistory (id INTEGER PRIMARY KEY AUTOINCREMENT, busId INTEGER, paymentDateTime TEXT, referenceId TEXT, valid_upto TEXT, userId INTEGER, amount INTEGER, status TEXT CHECK(status IN ('Expired', 'Active')), FOREIGN KEY(busId) REFERENCES BusDetails(busId), FOREIGN KEY(userId) REFERENCES users(userId))");

        db.execSQL("CREATE TABLE feedback (\n" +
                "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "    type TEXT,\n" +
                "    description TEXT,\n" +
                "    userID INTEGER,\n" +
                "    FOREIGN KEY(userID) REFERENCES users(userID)\n" +
                ");");
        db.execSQL("INSERT INTO " + USERS_TABLE + " (" + COLUMN_NAME + ", " + COLUMN_DESTINATION_BUS_ID + ", " + COLUMN_DESIGNATION + ", " + COLUMN_PHONE_NUMBER + ") VALUES ('User1', 1, 'faculty', '1234567890')");
        db.execSQL("INSERT INTO " + USERS_TABLE + " (" + COLUMN_NAME + ", " + COLUMN_DESTINATION_BUS_ID + ", " + COLUMN_DESIGNATION + ", " + COLUMN_PHONE_NUMBER + ") VALUES ('User2', 2, 'faculty', '2345678901')");
        db.execSQL("INSERT INTO " + USERS_TABLE + " (" + COLUMN_NAME + ", " + COLUMN_DESTINATION_BUS_ID + ", " + COLUMN_DESIGNATION + ", " + COLUMN_PHONE_NUMBER + ") VALUES ('User3', 1, 'faculty', '3456789012')");
        db.execSQL("INSERT INTO " + USERS_TABLE + " (" + COLUMN_NAME + ", " + COLUMN_DESTINATION_BUS_ID + ", " + COLUMN_DESIGNATION + ", " + COLUMN_PHONE_NUMBER + ") VALUES ('User4', 2, 'faculty', '4567890123')");

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, "Admin");
        values.put(COLUMN_DESTINATION_BUS_ID, 1);
        values.put(COLUMN_PASSWORD, "Admin");
        values.put(COLUMN_BLOOD_GROUP, "O+");
        values.put(COLUMN_PHONE_NUMBER, "9876543210");
        values.put(COLUMN_ADDRESS, "Admin Address");
        values.put(COLUMN_DESIGNATION, "Admin");

        db.insert(USERS_TABLE, null, values);


        ContentValues valuesIncharge = new ContentValues();
        valuesIncharge.put(COLUMN_NAME, "Incharge");
        valuesIncharge.put(COLUMN_DESTINATION_BUS_ID, 1);
        valuesIncharge.put(COLUMN_PASSWORD, "Incharge");
        valuesIncharge.put(COLUMN_BLOOD_GROUP, "AB+");
        valuesIncharge.put(COLUMN_PHONE_NUMBER, "9876543210");
        valuesIncharge.put(COLUMN_ADDRESS, "Incharge Address");
        valuesIncharge.put(COLUMN_DESIGNATION, "Incharge");

        db.insert(USERS_TABLE, null, valuesIncharge);

        db.execSQL("CREATE TABLE Wallet (\n" +
                "    id INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "    userID INTEGER,\n" +
                "    totalAmountAvailable INTEGER DEFAULT 0,\n" +
                "    FOREIGN KEY (userID) REFERENCES users(userID)\n" +
                ");");

        db.execSQL("CREATE TABLE Requests (\n" +
                "    request_id INTEGER PRIMARY KEY AUTOINCREMENT,\n" +
                "    requestor_id INTEGER REFERENCES users(userID),\n" +
                "    bus_id INTEGER REFERENCES BusDetails(busId),\n" +
                "    status TEXT\n" +
                ");\n");


//        db.execSQL("CREATE TABLE Drivers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, contact TEXT, busId INTEGER, FOREIGN KEY(busId) REFERENCES BusDetails(busId))");
//        db.execSQL("CREATE TABLE Incharge (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, inchargeId INTEGER, contact TEXT, busId INTEGER, FOREIGN KEY(busId) REFERENCES BusDetails(busId))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USERS_TABLE);
        db.execSQL("DROP TABLE IF EXISTS BusDetails");
        db.execSQL("DROP TABLE IF EXISTS Wallet");
        db.execSQL("DROP TABLE IF EXISTS travelRequests");
        db.execSQL("DROP TABLE IF EXISTS paymentsHistory");
        db.execSQL("DROP TABLE IF EXISTS Requests");
        onCreate(db);
    }

    public long insertWallet(long userID) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userID);
        values.put("totalAmountAvailable", 0);
        long id = db.insert("Wallet", null, values);
        db.close();
        return id;
    }

    @SuppressLint("Range")
    public int updateWallet(int userID, int amountToAdd) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + "totalAmountAvailable" + " FROM " + "Wallet" + " WHERE " + COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userID)});

        int currentAmount = 0;
        if (cursor.moveToFirst()) {
            currentAmount = cursor.getInt(cursor.getColumnIndex("totalAmountAvailable"));
        }
        cursor.close();

        int newAmount = currentAmount + amountToAdd;

        ContentValues values = new ContentValues();
        values.put("totalAmountAvailable", newAmount);

        return db.update("Wallet", values, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(userID)});
    }



    public long insertUser(Context context, String designation, String name, int destination_bus_id, String password, String bloodGroup, String phoneNumber, String address, String boardingPoint, String annualOrDialy) {
        SQLiteDatabase db = this.getWritableDatabase();
        if (name.isEmpty() || String.valueOf(destination_bus_id).isEmpty() || password.isEmpty() || bloodGroup.isEmpty() || phoneNumber.isEmpty() || address.isEmpty()) {
            Toast.makeText(context, "Fill all fields", Toast.LENGTH_SHORT).show();
            return -1;
        }

        // Validate PhoneNumber (should be 10 digits of numbers only)
        if (phoneNumber.length() != 10 || !TextUtils.isDigitsOnly(phoneNumber)) {
            Toast.makeText(context, "Phone Number should be 10 digits of numbers only", Toast.LENGTH_SHORT).show();
            return -1;
        }

        ContentValues values = new ContentValues();
        values.put(COLUMN_DESIGNATION, designation);
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DESTINATION_BUS_ID, destination_bus_id);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_BLOOD_GROUP, bloodGroup);
        values.put(COLUMN_PHONE_NUMBER, phoneNumber);
        values.put(COLUMN_ADDRESS, address);
        values.put(COLUMN_BOARDING_POINT, boardingPoint);
        values.put(COLUMN_ANNUAL_OR_DIALY, annualOrDialy);

        long result = db.insert(USERS_TABLE, null, values);
        db.close();

        return result;
    }

    @SuppressLint("Range")
    public UserDetails getUser(String username, String password, String role, String annualOrDialy) {
        SQLiteDatabase db = this.getReadableDatabase();
        UserDetails userDetails = null;
        Cursor cursor = db.rawQuery("SELECT * FROM " + USERS_TABLE + " WHERE " + COLUMN_NAME + " = ? AND " + COLUMN_PASSWORD + " = ? AND " + COLUMN_DESIGNATION + " = ?", new String[]{username, password, role});
        if (cursor.moveToFirst()) {
            int userID = cursor.getInt(cursor.getColumnIndex(COLUMN_USER_ID));
            String name = cursor.getString(cursor.getColumnIndex(COLUMN_NAME));
            int destination_bus_id = cursor.getInt(cursor.getColumnIndex(COLUMN_DESTINATION_BUS_ID));
            String boardingPoint = cursor.getString(cursor.getColumnIndex(COLUMN_BOARDING_POINT));
            String bloodGroup = cursor.getString(cursor.getColumnIndex(COLUMN_BLOOD_GROUP));
            String phoneNumber = cursor.getString(cursor.getColumnIndex(COLUMN_PHONE_NUMBER));
            String address = cursor.getString(cursor.getColumnIndex(COLUMN_ADDRESS));
            String designation = cursor.getString(cursor.getColumnIndex("designation"));
            String annualOrDialy1 = cursor.getString(cursor.getColumnIndex(COLUMN_ANNUAL_OR_DIALY));


//            if (role.equalsIgnoreCase("student")) {
//                if (!annualOrDialy1.equalsIgnoreCase(annualOrDialy)) {
//                    return null;
//                }
//            }


            userDetails = new UserDetails(userID, name,password, destination_bus_id, bloodGroup, phoneNumber, address, designation, boardingPoint, annualOrDialy1);
        }
        cursor.close();
        return userDetails;
    }


    public long insertBusDetails(long busId, String route, int totalSeats, int availableSeats, int occupiedSeats, String startTime, String arrivalTime, long driverId, long inchargeId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("busId", busId);
        values.put("route", route);
        values.put("totalSeats", totalSeats);
        values.put("availableSeats", availableSeats);
        values.put("occupiedSeats", occupiedSeats);
        values.put("driverId", driverId);
        values.put("inchargeId", inchargeId);
        values.put("startTime", startTime);
        values.put("arrivalTime", arrivalTime);
        long id = db.insert("BusDetails", null, values);
        db.close();
        return id;
    }

    public long insertDriver(String name, String contact, long busId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DESTINATION_BUS_ID, busId);
        values.put(COLUMN_PASSWORD, name);
        values.put(COLUMN_BLOOD_GROUP, "");
        values.put(COLUMN_PHONE_NUMBER, contact);
        values.put(COLUMN_ADDRESS, name + " Address");
        values.put(COLUMN_DESIGNATION, "Driver");
        long id = db.insert(USERS_TABLE, null, values);
        db.close();
        return id;
    }

    public long insertIncharge(String name, String contact, long busId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_DESTINATION_BUS_ID, busId);
        values.put(COLUMN_PASSWORD, name);
        values.put(COLUMN_BLOOD_GROUP, "");
        values.put(COLUMN_PHONE_NUMBER, contact);
        values.put(COLUMN_ADDRESS, name + " Address");
        values.put(COLUMN_DESIGNATION, "Incharge");
        long id = db.insert(USERS_TABLE, null, values);
        db.close();
        return id;
    }

    public boolean isBusIdAvailable(long busId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query("BusDetails", new String[]{"busId"}, "busId=?", new String[]{String.valueOf(busId)}, null, null, null);
        boolean available = cursor.getCount() == 0;
        cursor.close();
        db.close();
        return available;
    }

//    public boolean isInchargeIdAvailable(long inchargeId) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor cursor = db.query("Incharge", new String[]{"id"}, "inchargeId=?", new String[]{String.valueOf(inchargeId)}, null, null, null);
//        boolean available = cursor.getCount() == 0;
//        cursor.close();
//        db.close();
//        return available;
//    }

    public Cursor getBusDetails(int busId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                "totalSeats",
                "availableSeats",
                "occupiedSeats",
                "driverId",
                "route"
        };
        String selection = "busId = ?";
        String[] selectionArgs = {String.valueOf(busId)};

        return db.query(
                "BusDetails",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
    }

    public Cursor getDriverDetails(int driverId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                COLUMN_NAME,
                COLUMN_PHONE_NUMBER,
        };
        String selection = "userID = ?";
        String[] selectionArgs = {String.valueOf(driverId)};

        return db.query(
                USERS_TABLE,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
    }

    public Cursor getAllBusDetails() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                "BusDetails",
                null,
                null,
                null,
                null,
                null,
                null
        );
    }

    @SuppressLint("Range")
    public int getTotalAmount(int userID) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {"totalAmountAvailable"};
        String selection = COLUMN_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userID)};
        Cursor cursor = db.query("Wallet", projection, selection, selectionArgs, null, null, null);
        int totalAmount = 0;
        if (cursor.moveToFirst()) {
            totalAmount = cursor.getInt(cursor.getColumnIndex("totalAmountAvailable"));
        }
        cursor.close();
        return totalAmount;
    }



    public Cursor getAllDrivers() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                COLUMN_USER_ID,
                COLUMN_NAME,
                COLUMN_DESTINATION_BUS_ID,
                COLUMN_PASSWORD,
                COLUMN_BLOOD_GROUP,
                COLUMN_PHONE_NUMBER,
                COLUMN_ADDRESS,
                COLUMN_DESIGNATION
        };
        String selection = COLUMN_DESIGNATION + " = ?";
        String[] selectionArgs = { "Driver" };
        return db.query(
                USERS_TABLE,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
    }

    public Cursor getAllStudents() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                COLUMN_USER_ID,
                COLUMN_NAME,
                COLUMN_DESTINATION_BUS_ID,
                COLUMN_PASSWORD,
                COLUMN_BLOOD_GROUP,
                COLUMN_PHONE_NUMBER,
                COLUMN_ADDRESS,
                COLUMN_DESIGNATION
        };
        String selection = COLUMN_DESIGNATION + " = ?";
        String[] selectionArgs = { "Student" };
        return db.query(
                USERS_TABLE,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
    }

    public Cursor getAllFaculty(int busId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                COLUMN_USER_ID,
                COLUMN_NAME,
                COLUMN_DESTINATION_BUS_ID,
                COLUMN_PASSWORD,
                COLUMN_BLOOD_GROUP,
                COLUMN_PHONE_NUMBER,
                COLUMN_ADDRESS,
                COLUMN_DESIGNATION
        };
        String selection = COLUMN_DESIGNATION + " = ? AND " + COLUMN_DESTINATION_BUS_ID + " = ?";
        String[] selectionArgs = { "faculty", String.valueOf(busId) };
        return db.query(
                USERS_TABLE,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
    }

    public Cursor getAllStudents(int busId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                COLUMN_USER_ID,
                COLUMN_NAME,
                COLUMN_DESTINATION_BUS_ID,
                COLUMN_PASSWORD,
                COLUMN_BLOOD_GROUP,
                COLUMN_PHONE_NUMBER,
                COLUMN_ADDRESS,
                COLUMN_DESIGNATION
        };
        String selection = COLUMN_DESIGNATION + " = ? AND " + COLUMN_DESTINATION_BUS_ID + " = ?";
        String[] selectionArgs = { "Student", String.valueOf(busId) };
        return db.query(
                USERS_TABLE,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
    }


    public Cursor getAllIncharges() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                COLUMN_USER_ID,
                COLUMN_NAME,
                COLUMN_DESTINATION_BUS_ID,
                COLUMN_PASSWORD,
                COLUMN_BLOOD_GROUP,
                COLUMN_PHONE_NUMBER,
                COLUMN_ADDRESS,
                COLUMN_DESIGNATION
        };
        String selection = COLUMN_DESIGNATION + " = ?";
        String[] selectionArgs = { "Incharge" };
        return db.query(
                USERS_TABLE,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
    }

    public long addFeedback(SQLiteDatabase db, String type, String description, int userID) {
        ContentValues values = new ContentValues();
        values.put("type", type);
        values.put("description", description);
        values.put("userID", userID);

        long id = db.insert("feedback", null, values);
        return id;
    }
    public Cursor getAllFeedbackDetails() {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] projection = {
                "id",
                "type",
                "description",
                "userID"
        };
        return db.query(
                "feedback", // Table name
                projection,
                null,
                null,
                null,
                null,
                null
        );
    }
    @SuppressLint("Range")
    public ArrayList<Bus> getBusesByDestination(String destination) {
        ArrayList<Bus> buses = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM BusDetails WHERE lower(route) = lower(?)", new String[]{destination});
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int busId = cursor.getInt(cursor.getColumnIndex("busId"));
                String startTime = cursor.getString(cursor.getColumnIndex("startTime"));
                int totalSeats = cursor.getInt(cursor.getColumnIndex("totalSeats"));
                int inchargeId = cursor.getInt(cursor.getColumnIndexOrThrow("inchargeId"));
                int driverId = cursor.getInt(cursor.getColumnIndexOrThrow("driverId"));
                int occupiedSeats = cursor.getInt(cursor.getColumnIndexOrThrow("occupiedSeats"));
                int availableSeats = cursor.getInt(cursor.getColumnIndexOrThrow("availableSeats"));
                String arrivalTime = cursor.getString(cursor.getColumnIndexOrThrow("arrivalTime"));
                Bus bus = new Bus(busId, destination, inchargeId, driverId, totalSeats, occupiedSeats, availableSeats, startTime, arrivalTime);
                buses.add(bus);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return buses;
    }
    @SuppressLint("Range")
    public List<TravelRequests> getAllTravelRequests() {
        List<TravelRequests> requestsList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM travelRequests", null);
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                int busId = cursor.getInt(cursor.getColumnIndex("busId"));
                int userId = cursor.getInt(cursor.getColumnIndex("userId"));
                String status = cursor.getString(cursor.getColumnIndex("status"));
                String date = cursor.getString(cursor.getColumnIndex("date"));

                TravelRequests request = new TravelRequests(id, busId, userId, status, date);
                requestsList.add(request);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return requestsList;
    }


    public void updateTravelRequestStatus(int requestId, String newStatus) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status", newStatus);

        String selection = "id = ?";
        String[] selectionArgs = { String.valueOf(requestId) };

        int count = db.update("travelRequests", values, selection, selectionArgs);
        db.close();
    }
    @SuppressLint("Range")
    public List<PaymentHistory> getPaymentHistoryByUserId(int userId) {
        List<PaymentHistory> paymentHistoryList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {"id", "busId", "paymentDateTime", "referenceId", "valid_upto", "userId", "amount", "status"};
        String selection = "userId = ?";
        String[] selectionArgs = {String.valueOf(userId)};
        Cursor cursor = db.query("paymentsHistory", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                int busId = cursor.getInt(cursor.getColumnIndex("busId"));
                String paymentDateTime = cursor.getString(cursor.getColumnIndex("paymentDateTime"));
                String referenceId = cursor.getString(cursor.getColumnIndex("referenceId"));
                String validUpto = cursor.getString(cursor.getColumnIndex("valid_upto"));
                int amount = cursor.getInt(cursor.getColumnIndex("amount"));
                String status = cursor.getString(cursor.getColumnIndex("status"));

                PaymentHistory paymentHistory = new PaymentHistory(id, busId, paymentDateTime, referenceId, validUpto, userId, amount, status);
                paymentHistoryList.add(paymentHistory);
            } while (cursor.moveToNext());
            cursor.close();
        }
        db.close();
        return paymentHistoryList;
    }

    public boolean insertRequest(int userId, int busId, String status) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("requestor_id", userId);
        contentValues.put("bus_id", busId);
        contentValues.put("status", status);

        long result = db.insert("Requests", null, contentValues);
        return result != -1;
    }


}
