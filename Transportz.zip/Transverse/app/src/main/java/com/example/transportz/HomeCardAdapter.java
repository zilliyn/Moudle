package com.example.transportz;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HomeCardAdapter extends RecyclerView.Adapter<HomeCardAdapter.HomeCardViewHolder> {
    private List<HomeCardModel> homeCardList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(String cardName, Context context);
    }


    public HomeCardAdapter(List<HomeCardModel> homeCardList, OnItemClickListener listener) {
        this.homeCardList = homeCardList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HomeCardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_item_card, parent, false);
        return new HomeCardViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HomeCardViewHolder holder, int position) {
        HomeCardModel homeCardModel = homeCardList.get(position);
        holder.idTVCardName.setText(homeCardModel.getCardName());
        holder.cardImg.setImageResource(homeCardModel.getImageName());
        holder.bind(homeCardModel, listener, holder.itemView.getContext());
    }


    @Override
    public int getItemCount() {
        return homeCardList.size();
    }


    public static class HomeCardViewHolder extends RecyclerView.ViewHolder {
        TextView idTVCardName;
        ImageView cardImg;

        public HomeCardViewHolder(@NonNull View itemView) {
            super(itemView);
            idTVCardName = itemView.findViewById(R.id.idTVCardName);
            cardImg = itemView.findViewById(R.id.cardImg);
        }

        public void bind(final HomeCardModel homeCardModel, final OnItemClickListener listener, final Context context) {
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(homeCardModel.getCardName(), context);
                }
            });
        }

    }

    private int getImageResourceByName(Context context, String imageName) {
        return context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
    }
}
