package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;

import java.util.List;

public class AnnualPaymentList extends AppCompatActivity {
    private RecyclerView recyclerView;
    private AnnualPaymentsAdapter adapter;
    private List<PaymentHistory> paymentHistoryList;

    SharedPreferences sf;
    DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_annual_payment_list);

        dbHelper = new DBHelper(this);
        sf = getSharedPreferences("UserDetails", MODE_PRIVATE);
        int userId = sf.getInt("userId", -1);
        paymentHistoryList = dbHelper.getPaymentHistoryByUserId(userId);

        recyclerView = findViewById(R.id.paymentsList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AnnualPaymentsAdapter(paymentHistoryList, AnnualPaymentList.this);
        recyclerView.setAdapter(adapter);
    }

}