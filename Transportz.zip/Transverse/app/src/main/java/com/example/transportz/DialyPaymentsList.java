package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class DialyPaymentsList extends AppCompatActivity {

    private RecyclerView paymentsList;
    private DailyPaymentsAdapter adapter;
    private List<PaymentHistory> paymentHistoryList;
    SharedPreferences sf;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialy_payments_list);

        dbHelper = new DBHelper(this);
        paymentsList = findViewById(R.id.paymentsList);
        paymentHistoryList = new ArrayList<>();
        sf = getSharedPreferences("UserDetails", MODE_PRIVATE);
        int userId = sf.getInt("userId", -1);
        paymentHistoryList = dbHelper.getPaymentHistoryByUserId(userId);

        adapter = new DailyPaymentsAdapter(paymentHistoryList);
        paymentsList.setAdapter(adapter);
        paymentsList.setLayoutManager(new LinearLayoutManager(this));
    }
}
