package com.example.transportz;

public class HomeCardModel {
    private String cardName;
    private int imageName;

    public HomeCardModel(String cardName, int imageName) {
        this.cardName = cardName;
        this.imageName = imageName;
    }

    public int getImageName() {
        return imageName;
    }

    public void setImageName(int imageName) {
        this.imageName = imageName;
    }

    public HomeCardModel(String cardName) {
        this.cardName = cardName;
    }

    public String getCardName() {
        return cardName;
    }
}

