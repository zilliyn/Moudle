package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BusPass extends AppCompatActivity {

    private LinearLayout frontLayout;
    private LinearLayout backLayout;
    private boolean isFront = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_pass);

        frontLayout = findViewById(R.id.frontLayout);
        backLayout = findViewById(R.id.backLayout);

        // Initially hide the back layout
        backLayout.setVisibility(View.GONE);

        CardView cardView = findViewById(R.id.cardView);
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flipCard();
            }
        });

        // Populate the front layout with user details from the Users table
        populateFrontLayout();
        populateBackLayout();
    }

    private void flipCard() {
        if (isFront) {
            // Flip to back
            frontLayout.setVisibility(View.GONE);
            backLayout.setVisibility(View.VISIBLE);
        } else {
            // Flip to front
            backLayout.setVisibility(View.GONE);
            frontLayout.setVisibility(View.VISIBLE);
        }

        isFront = !isFront;
    }

    private void populateFrontLayout() {
        SharedPreferences userDetails = getSharedPreferences("UserDetails", MODE_PRIVATE);
        String boardingPoint = userDetails.getString("boardingPoint", "");
        String bloodGroup = userDetails.getString("bloodGroup", "");
        String phoneNumber = userDetails.getString("phNo", "");
        int userId = userDetails.getInt("userId", -1);

        TextView boardingPointTextView = findViewById(R.id.boardingPointTextView);
        boardingPointTextView.setText(boardingPoint);

        TextView bloodGroupTextView = findViewById(R.id.bloodGroupTextView);
        bloodGroupTextView.setText(bloodGroup);

        TextView phoneNumberTextView = findViewById(R.id.phoneNumberTextView);
        phoneNumberTextView.setText(phoneNumber);
    }


    private void populateBackLayout() {
        SharedPreferences userDetails = getSharedPreferences("UserDetails", MODE_PRIVATE);
        int userId = userDetails.getInt("userId", -1);

        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT MAX(valid_upto) FROM paymentsHistory WHERE userId = ?", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            String longestValidUpto = cursor.getString(0);
            TextView validUptoTextView = findViewById(R.id.validUptoTextView);
            if(longestValidUpto != null) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDateTime dateTime = LocalDateTime.parse(longestValidUpto, formatter);

                LocalDate date = dateTime.toLocalDate();
                DateTimeFormatter displayFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                String formattedDate = date.format(displayFormatter);
                validUptoTextView.setText(formattedDate);
            }
        }
        cursor.close();
    }
}