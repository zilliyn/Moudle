package com.example.transportz;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RequestBus extends AppCompatActivity implements BusDetailsAdapter.OnItemClickListener{

    private RecyclerView rv;
    private EditText busRoute;
    private BusDetailsAdapter adapter;
    private List<Bus> busList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_bus);

        rv = findViewById(R.id.availableBuses);
        busRoute = findViewById(R.id.busRouteET);

        DBHelper dbHelper = new DBHelper(this);


        busList = new ArrayList<>();

        Button checkBtn = findViewById(R.id.checkBtn);
        checkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String route = busRoute.getText().toString().trim();
                if (route.isEmpty()) {
                    Toast.makeText(RequestBus.this, "Please enter a route", Toast.LENGTH_SHORT).show();
                } else {
                    busList.clear();
                    busList = dbHelper.getBusesByDestination(route);
                    if (busList.isEmpty()) {
                        Toast.makeText(RequestBus.this, "No buses available for entered route", Toast.LENGTH_SHORT).show();
                    }
                        adapter = new BusDetailsAdapter(busList, RequestBus.this, true);
                        rv.setAdapter(adapter);
                        rv.setLayoutManager(new LinearLayoutManager(RequestBus.this));

                    adapter.notifyDataSetChanged();
                }
            }
        });

       /* ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(RequestBus.this, R.color.white)));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);
        actionBar.setDisplayShowTitleEnabled(true);*/
    }

    @Override
    public void onItemClick(Bus bus) {
        SharedPreferences userDetails = getSharedPreferences("UserDetails", MODE_PRIVATE);
        int userId = userDetails.getInt("userId", -1); // Assuming -1 is a default value if userId is not found

        if (userId != -1) {
            DBHelper databaseHelper = new DBHelper(RequestBus.this);
            SQLiteDatabase db = databaseHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("busId", bus.getId());
            values.put("userId", userId);
            values.put("status", "Pending");
            values.put("date", (new Date()).toString());
            long newRowId = db.insert("travelRequests", null, values);
            if (newRowId != -1) {
                Toast.makeText(RequestBus.this, "Request sent!", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(RequestBus.this, AdminHome.class);
                startActivity(i);
                finish();
            } else {
                Toast.makeText(RequestBus.this, "Failed to send request!", Toast.LENGTH_SHORT).show();
            }
            db.close();
        } else {
            Toast.makeText(this, "User ID not found", Toast.LENGTH_SHORT).show();
        }
    }

}