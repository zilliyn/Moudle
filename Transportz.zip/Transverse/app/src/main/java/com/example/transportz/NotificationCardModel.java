package com.example.transportz;

public class NotificationCardModel {
    private String studentId;
    private String status;
    private String date;

    public NotificationCardModel(String studentId, String status, String date) {
        this.studentId = studentId;
        this.status = status;
        this.date = date;
    }

    public String getStudentId() {
        return studentId;
    }

    public String getStatus() {
        return status;
    }

    public String getDate() {
        return date;
    }
}
