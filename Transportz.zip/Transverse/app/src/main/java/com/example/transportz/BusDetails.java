package com.example.transportz;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BusDetails extends AppCompatActivity implements BusDetailsAdapter.OnItemClickListener{
    private RecyclerView rv;
    private BusDetailsAdapter adapter;
    private List<Bus> busList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_details);

        rv = findViewById(R.id.detailCards);

        DBHelper dbHelper = new DBHelper(this);
        Cursor cursor = dbHelper.getAllBusDetails();

        List<Bus> busList = new ArrayList<>();
        while (cursor.moveToNext()) {
            int busId = cursor.getInt(cursor.getColumnIndexOrThrow("busId"));
            String route = cursor.getString(cursor.getColumnIndexOrThrow("route"));
            int totalSeats = cursor.getInt(cursor.getColumnIndexOrThrow("totalSeats"));
            int availableSeats = cursor.getInt(cursor.getColumnIndexOrThrow("availableSeats"));
            int occupiedSeats = cursor.getInt(cursor.getColumnIndexOrThrow("occupiedSeats"));
            int driverId = cursor.getInt(cursor.getColumnIndexOrThrow("driverId"));
            int inchargeId = cursor.getInt(cursor.getColumnIndexOrThrow("inchargeId"));
            String startTime = cursor.getString(cursor.getColumnIndexOrThrow("startTime"));
            String arrivalTime  = cursor.getString(cursor.getColumnIndexOrThrow("arrivalTime"));

            Bus bus = new Bus(busId, route, inchargeId, driverId, totalSeats, occupiedSeats, availableSeats, startTime, arrivalTime);
            busList.add(bus);
        }

        adapter = new BusDetailsAdapter(busList, this, false);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new LinearLayoutManager(this));

       /* ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(BusDetails.this, R.color.white)));
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.back);
        actionBar.setDisplayShowTitleEnabled(true);*/
    }

    @Override
    public void onItemClick(Bus bus) {
        Intent intent = new Intent(BusDetails.this, IndividualBusDetals.class);
        intent.putExtra("busId", bus.getId());
        startActivity(intent);
    }
}
