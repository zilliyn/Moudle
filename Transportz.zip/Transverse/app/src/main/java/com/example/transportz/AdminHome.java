package com.example.transportz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AdminHome extends AppCompatActivity {

    private RecyclerView rv;
    private HomeCardAdapter adapter;
    private List<HomeCardModel> homeCardList;
    private ImageView menuIcon;
    LinearLayout ll, rvLL;

    TextView prAddress, prBus, prContact, prName;
    DBHelper dbHelper;
    List<TravelRequests> notificationCardList;
    String role;
    private LinearLayout frontLayout;
    private LinearLayout backLayout;
    private boolean isFront = true;
    private String annualOrDialy;
    private List<TravelRequests> travelRequestsList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
      /*  CalendarView calendarView = findViewById(R.id.calendar);
        calendarView.setDate(System.currentTimeMillis());
        calendarView.setClickable(false);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                // Reset the selected date to the current date
                calendarView.setDate(System.currentTimeMillis());
            }
        });*/
        rv = findViewById(R.id.homeCards);
        SharedPreferences userDetails = getSharedPreferences("UserDetails", MODE_PRIVATE);
        role = userDetails.getString("designation", "Admin");
        String busId = String.valueOf(userDetails.getInt("destination", 1));
        String address = userDetails.getString("address", "");
        String phNo = userDetails.getString("phNo", "");
        annualOrDialy = userDetails.getString("annualOrDialy", "dialy");
        String username = userDetails.getString("username", "");
        TabLayout tabLayout = findViewById(R.id.tabLayout);

        ll = findViewById(R.id.profileLayout);
//        rvLL = findViewById(R.id.rvLL);

        dbHelper = new DBHelper(this);

        prName = findViewById(R.id.profileName);

        prAddress = findViewById(R.id.profileAddress);
        prBus = findViewById(R.id.profileBus);
        prContact = findViewById(R.id.profileContact);

        prName.setText(username);
        prName.setText(username);
        prAddress.setText(address);
        prBus.setText("Bus-"+busId);
        prContact.setText(phNo);

        homeCardList = new ArrayList<>();
        notificationCardList = new ArrayList<>();

        Log.d("Annual", annualOrDialy);

        if(role.toLowerCase().equals("admin")) {
            homeCardList.add(new HomeCardModel("Bus Details", R.drawable.busdet));
            homeCardList.add(new HomeCardModel("Add Bus", R.drawable.addbus));
            homeCardList.add(new HomeCardModel("Student Details", R.drawable.student));
            homeCardList.add(new HomeCardModel("Bus Incharge Details", R.drawable.incharge ));
            homeCardList.add(new HomeCardModel("Driver Details", R.drawable.driver ));
            homeCardList.add(new HomeCardModel("Feedback Details", R.drawable.feedback));


            tabLayout.addTab(tabLayout.newTab().setText("Dashboard"));
            tabLayout.addTab(tabLayout.newTab().setText("Notifications"));
        } else if(role.toLowerCase().equals("incharge")) {
            homeCardList.add(new HomeCardModel("Student Details", R.drawable.student));
            homeCardList.add(new HomeCardModel("Faculty Details", R.drawable.faculty));

            tabLayout.addTab(tabLayout.newTab().setText("Dashboard"));
            tabLayout.addTab(tabLayout.newTab().setText("Profile"));

        } else if(role.toLowerCase().equals("student")) {
            if(annualOrDialy.equals("dialy")) {
                homeCardList.add(new HomeCardModel("Board a Bus", R.drawable.bus_board));
                homeCardList.add(new HomeCardModel("Bus Pass", R.drawable.bus_pass));
                homeCardList.add(new HomeCardModel("Wallet", R.drawable.wallet));
                tabLayout.addTab(tabLayout.newTab().setText("Dashboard"));
                tabLayout.addTab(tabLayout.newTab().setText("Profile"));

                notificationCardList = dbHelper.getAllTravelRequests();
            } else if(annualOrDialy.equals("annual")){
                findViewById(R.id.busPass).setVisibility(View.GONE);
                homeCardList.add(new HomeCardModel("Attendance calendar", R.drawable.calendar));
                tabLayout.addTab(tabLayout.newTab().setText("Dashboard"));
                tabLayout.addTab(tabLayout.newTab().setText("Profile"));
            }
        }

        adapter = new HomeCardAdapter(homeCardList, new HomeCardAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(String cardName, Context context) {
                if (cardName.equals("Bus Details")) {
                    Intent intent = new Intent(context, BusDetails.class);
                    startActivity(intent);
                } else if (cardName.equals("Bus Incharge Details")) {
                    Intent intent = new Intent(context, DetailsPage.class);
                    intent.putExtra("cardName", "Incharge");
                    startActivity(intent);
                } else if (cardName.equals("Driver Details")) {
                    Intent intent = new Intent(context, DetailsPage.class);
                    intent.putExtra("cardName", "Driver");
                    startActivity(intent);
                } else if (cardName.equals("Student Details")) {
                    Intent intent = new Intent(context, DetailsPage.class);
                    intent.putExtra("cardName", "Student");
                    startActivity(intent);
                } else if (cardName.equals("Add Bus")) {
                    Intent intent = new Intent(context, AddBus.class);
                    startActivity(intent);
                } else if(cardName.equals("Feedback Details")) {
                    Intent intent = new Intent(context, DetailsPage.class);
                    intent.putExtra("cardName", "Feedback");
                    startActivity(intent);
                } else if (cardName.equals("Faculty Details")) {
                    Intent intent = new Intent(context, DetailsPage.class);
                    intent.putExtra("cardName", "faculty");
                    startActivity(intent);
                } else if (cardName.equals("Wallet")) {
                    Intent intent = new Intent(context, Wallet.class);
                    startActivity(intent);
                } else if(cardName.equals("Bus Pass")) {
                    Intent intent = new Intent(context, BusPass.class);
                    startActivity(intent);
                } else if(cardName.equals("Board a Bus")) {
                    Intent intent = new Intent(context, CheckAvailability.class);
                    startActivity(intent);
                } else if(cardName.equals("Attendance calendar")) {
                    Intent intent = new Intent(context, CalendarActivity.class);
                    startActivity(intent);
                }
            }
        });

       /* ActionBar actionBar = getSupportActionBar();
        actionBar.setBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.main)));
        actionBar.setElevation(5);
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setDisplayShowCustomEnabled(true);

        */

     /*   View customActionBar = getLayoutInflater().inflate(R.layout.action_bar_custom, null);

        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.MATCH_PARENT);
        getSupportActionBar().setCustomView(customActionBar, layoutParams);
*/
        menuIcon = findViewById(R.id.menuBar);
        menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPopupMenu();
            }
        });
        if(role.toLowerCase().equals("admin")) {
            menuIcon.setVisibility(View.VISIBLE);
        }
        else {
            menuIcon.setVisibility(View.GONE);
        }

        TextView actionBarTitle = findViewById(R.id.title);
        ImageView logoutBtn = findViewById(R.id.logout);

        actionBarTitle.setText("Home");
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Index.class);
                userDetails.edit().clear();
                startActivity(i);
                finish();
            }
        });

        ll.setVisibility(View.GONE);
        rv.setAdapter(adapter);
        rv.setLayoutManager(new GridLayoutManager(getApplicationContext(),2,LinearLayoutManager.VERTICAL,false));
        frontLayout = findViewById(R.id.frontLayout);
        backLayout = findViewById(R.id.backLayout);

        // Initially hide the back layout
        backLayout.setVisibility(View.GONE);

        CardView cardView = findViewById(R.id.cardView);
        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flipCard();
            }
        });

        // Populate the front layout with user details from the Users table
        populateFrontLayout();
        populateBackLayout();


        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            @SuppressLint("Range")
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        findViewById(R.id.busPass).setVisibility(View.GONE);
                        ll.setVisibility(View.GONE);
//                        rvLL.setVisibility(View.VISIBLE);
                        rv.setVisibility(View.VISIBLE);
                        rv.setAdapter(adapter);
                        rv.setLayoutManager(new GridLayoutManager(getApplicationContext(),2,LinearLayoutManager.VERTICAL,false));

                        if(!(role.toLowerCase().equals("student") && annualOrDialy.equalsIgnoreCase("annual"))) {
                            findViewById(R.id.busPass).setVisibility(View.GONE);
                        }
                        break;
                    case 1:
                        findViewById(R.id.busPass).setVisibility(View.GONE);
                        if(role.toLowerCase().equals("admin")) {
                            NotificationCardAdapter adapter1;
//                            rvLL.setVisibility(View.VISIBLE);
                            ll.setVisibility(View.GONE);
//                            NotificationCardAdapter notificationsAdapter = new NotificationCardAdapter(getApplicationContext(),notificationCardList, role);

                            String userDesignation = userDetails.getString("designation", "");
                            travelRequestsList = new ArrayList<>();
                            SQLiteDatabase db = dbHelper.getReadableDatabase();
                            String[] columns = {"id", "busId", "userId", "status", "date"};
                            Cursor cursor = db.query("travelRequests", columns, null, null, null, null, null);
                            if (cursor != null && cursor.moveToFirst()) {
                                do {
                                    int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                                    int busId = cursor.getInt(cursor.getColumnIndex("busId"));
                                    int userId1 = cursor.getInt(cursor.getColumnIndex("userId"));
                                    String status = cursor.getString(cursor.getColumnIndex("status"));
                                    String date = cursor.getString(cursor.getColumnIndex("date"));
                                    SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);
                                    SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yy", Locale.US);
                                    Date d = null;
                                    try {
                                        d = inputFormat.parse(date);
                                    } catch (ParseException e) {
                                        throw new RuntimeException(e);
                                    }
                                    String outputDate = outputFormat.format(d);
                                    travelRequestsList.add(new TravelRequests(id, busId, userId1, status, outputDate.toString()));
                                } while (cursor.moveToNext());
                                cursor.close();
                            }
                            db.close();
                            adapter1 = new NotificationCardAdapter(getApplicationContext(), travelRequestsList, role);
                            rv.setAdapter(adapter1);
                            rv.setLayoutManager(new GridLayoutManager(AdminHome.this,2,LinearLayoutManager.VERTICAL,false));
                        } else if(role.toLowerCase().equals("incharge") || role.toLowerCase().equals("student")) {
//                            rvLL.setVisibility(View.GONE);
                            ll.setVisibility(View.VISIBLE);
                            rv.setVisibility(View.GONE);
                        }

                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}

            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void showPopupMenu() {
        PopupMenu popupMenu = new PopupMenu(this, menuIcon);
        popupMenu.getMenuInflater().inflate(R.menu.drawer_menu, popupMenu.getMenu());
        if (!(role.equalsIgnoreCase("student") && annualOrDialy.equalsIgnoreCase("annual"))) {
            popupMenu.getMenu().removeItem(R.id.nav_requestBus);
            popupMenu.getMenu().removeItem(R.id.nav_payments_annual);
        }

        if ((role.equalsIgnoreCase("student") && annualOrDialy.equalsIgnoreCase("annual"))) {
            popupMenu.getMenu().removeItem(R.id.nav_payments_dialy);
        }

        if(role.equalsIgnoreCase("incharge")) {
            popupMenu.getMenu().removeItem(R.id.nav_change_password);
            popupMenu.getMenu().removeItem(R.id.nav_payments_dialy);
            popupMenu.getMenu().removeItem(R.id.nav_payments_annual);
        }
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                if(item.getItemId() == R.id.nav_feedback) {
                    Intent i = new Intent(AdminHome.this, AddFeedback.class);
                    startActivity(i);
                } else if(item.getItemId() == R.id.nav_notifications) {
                    Intent i = new Intent(AdminHome.this, TravelNotificationList.class);
                    startActivity(i);
                } else if(item.getItemId() == R.id.nav_payments_dialy) {
                    if((role.equalsIgnoreCase("student") && annualOrDialy.equalsIgnoreCase("dialy"))) {
                        Intent i = new Intent(AdminHome.this, DialyPaymentsList.class);
                        startActivity(i);
                    }
                } else if(item.getItemId() == R.id.nav_change_password) {
                    Intent i = new Intent(AdminHome.this, ChangePassword.class);
                    startActivity(i);
                } else if(item.getItemId() == R.id.nav_requestBus) {
                    Intent i = new Intent(AdminHome.this, RequestBus.class);
                    startActivity(i);
                } else if(item.getItemId() == R.id.nav_sub_annual) {
                    Intent i = new Intent(AdminHome.this, AnnualPaymentList.class);
                    startActivity(i);
                } else if(item.getItemId() == R.id.nav_sub_status) {
                    Intent i = new Intent(AdminHome.this, DialyPaymentsList.class);
                    startActivity(i);
                }

                return true;
            }
        });
        popupMenu.show();
    }

    private void flipCard() {
        if (isFront) {
            // Flip to back
            frontLayout.setVisibility(View.GONE);
            backLayout.setVisibility(View.VISIBLE);
        } else {
            // Flip to front
            backLayout.setVisibility(View.GONE);
            frontLayout.setVisibility(View.VISIBLE);
        }

        isFront = !isFront;
    }

    private void populateFrontLayout() {
        SharedPreferences userDetails = getSharedPreferences("UserDetails", MODE_PRIVATE);
        String boardingPoint = userDetails.getString("boardingPoint", "");
        String bloodGroup = userDetails.getString("bloodGroup", "");
        String phoneNumber = userDetails.getString("phNo", "");

        TextView boardingPointTextView = findViewById(R.id.boardingPointTextView);
        boardingPointTextView.setText("Boarding Point: " + boardingPoint);

        TextView bloodGroupTextView = findViewById(R.id.bloodGroupTextView);
        bloodGroupTextView.setText("Blood Group: " + bloodGroup);

        TextView phoneNumberTextView = findViewById(R.id.phoneNumberTextView);
        phoneNumberTextView.setText("Phone Number: " + phoneNumber);
    }

    private void populateBackLayout() {
        SharedPreferences userDetails = getSharedPreferences("UserDetails", MODE_PRIVATE);
        int userId = userDetails.getInt("userId", -1);

        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT MAX(valid_upto) FROM paymentsHistory WHERE userId = ?", new String[]{String.valueOf(userId)});
        if (cursor.moveToFirst()) {
            String longestValidUpto = cursor.getString(0);
            TextView validUptoTextView = findViewById(R.id.validUptoTextView);
            if(longestValidUpto != null) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                LocalDateTime dateTime = LocalDateTime.parse(longestValidUpto, formatter);

                LocalDate date = dateTime.toLocalDate();
                DateTimeFormatter displayFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                String formattedDate = date.format(displayFormatter);
                validUptoTextView.setText("Valid Upto: " + formattedDate);
            }
        }
        cursor.close();
    }

}