package com.example.transportz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class BusDetailsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Bus> busList;
    private OnItemClickListener listener;

    private boolean isRequestBusContext;

    public BusDetailsAdapter(List<Bus> busList, OnItemClickListener listener, boolean isRequestBusContext) {
        this.busList = busList;
        this.listener = listener;
        this.isRequestBusContext = isRequestBusContext;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bus_card, parent, false);
        return new BusDetailsViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof BusDetailsViewHolder) {
            BusDetailsViewHolder viewHolder = (BusDetailsViewHolder) holder;
            viewHolder.bind(busList.get(position), listener, isRequestBusContext);
        }
    }

    @Override
    public int getItemCount() {
        return busList.size();
    }

    public class BusDetailsViewHolder extends RecyclerView.ViewHolder {
        private TextView tvBusId;
        private TextView tvBusName;
        private TextView tvBusRoute;

        private Button viewDetailsButton;

        public BusDetailsViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBusId = itemView.findViewById(R.id.busId);
            tvBusRoute = itemView.findViewById(R.id.busRoute);
            viewDetailsButton = itemView.findViewById(R.id.completedIssueBtn);
        }

        public void bind(final Bus bus, final OnItemClickListener listener, boolean isRequestBusContext) {
            tvBusId.setText("Bus ID: " + bus.getId());
            tvBusRoute.setText("Bus Route: " + bus.getRoute());

            if (isRequestBusContext) {
                viewDetailsButton.setText("Request");
            } else {
                viewDetailsButton.setText("View Details");
            }

            viewDetailsButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.onItemClick(bus);
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Bus bus);
    }

}
