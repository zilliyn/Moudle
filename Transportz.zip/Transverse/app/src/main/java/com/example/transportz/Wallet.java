package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Wallet extends AppCompatActivity {

    private EditText amountEntered;
    private SharedPreferences userDetails;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);

         dbHelper = new DBHelper(this);

        amountEntered = findViewById(R.id.amountEntered);
        Button addCashBtn = findViewById(R.id.addCashBtn);
        TextView totalAmountTextView = findViewById(R.id.totalAvailableAmount);

        userDetails = getSharedPreferences("UserDetails", MODE_PRIVATE);
        int userID = userDetails.getInt("userId", -1);
        int totalAmount = dbHelper.getTotalAmount(userID);

        // Set the total amount in the TextView
        totalAmountTextView.setText("Total Amount Available: " + totalAmount);


        addCashBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amountText = amountEntered.getText().toString();
                if (!TextUtils.isEmpty(amountText)) {
                    int amount = Integer.parseInt(amountText);
                    updateWallet(userID, amount);
                } else {
                    Toast.makeText(Wallet.this, "Please enter an amount", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void updateWallet(int userID, int amount) {

        int rowsAffected = dbHelper.updateWallet(userID, amount);
        if (rowsAffected > 0) {
            Toast.makeText(this, "Wallet updated successfully", Toast.LENGTH_SHORT).show();
            amountEntered.setText("");
        } else {
            Toast.makeText(this, "Failed to update wallet", Toast.LENGTH_SHORT).show();
        }
    }
}
