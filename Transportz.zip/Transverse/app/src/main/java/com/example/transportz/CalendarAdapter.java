package com.example.transportz;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import java.util.List;

public class CalendarAdapter extends BaseAdapter {
    private final Context context;
    private final List<Integer> days;
    private final LayoutInflater inflater;

    public CalendarAdapter(Context context, List<Integer> days) {
        this.context = context;
        this.days = days;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return days.size();
    }

    @Override
    public Object getItem(int position) {
        return days.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = inflater.inflate(R.layout.calendar_item, parent, false);
        }

        TextView dayTextView = view.findViewById(R.id.dayTextView);
        int day = days.get(position);
        dayTextView.setText(String.valueOf(day));

        // Highlight logic here
        if (isHighlighted(day)) {
            dayTextView.setTextColor(ContextCompat.getColor(context, R.color.main));
        } else {
            dayTextView.setTextColor(ContextCompat.getColor(context, android.R.color.black));
        }

        return view;
    }

    private boolean isHighlighted(int day) {
        // Implement your logic to determine if the day should be highlighted
        // For example, highlight odd days
        return day % 2 != 0;
    }
}
