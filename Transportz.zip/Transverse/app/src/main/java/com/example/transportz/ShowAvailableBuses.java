package com.example.transportz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class ShowAvailableBuses extends AppCompatActivity {

    private RecyclerView recyclerView;
    private BusAdapter adapter;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_available_buses);
        dbHelper = new DBHelper(this);

        TextView destinationTV = findViewById(R.id.destinationTV);
        TextView dateTV = findViewById(R.id.date);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String destination = extras.getString("destination");
            String date = extras.getString("date");

            if (destination != null) {
                destinationTV.setText(destination);
            }

            if (date != null) {
                dateTV.setText(date);
            }
        }

        recyclerView = findViewById(R.id.availableBuses);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new BusAdapter(getAvailableBuses(getIntent().getStringExtra("destination")));
        recyclerView.setAdapter(adapter);
    }

    private ArrayList<Bus> getAvailableBuses(String destination) {
        return dbHelper.getBusesByDestination(destination);
    }
}